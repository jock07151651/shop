<?php

namespace catetree;

class Catetree
{
    public function catetree($cateRes) {
        return $this->sort($cateRes);
    }

    // 无限极
    public function sort($cateRes,$pid=0,$level=0) {
        // 定义一个静态数组
        static $arr = [];
        foreach ($cateRes as $k => $v) {
            if ($pid == $v['pid']) {
                $arr[] = $v;
                $v['level'] = $level;
                $this->sort($cateRes,$v['id'],$level+1);
            }
        }
        return $arr;
    }

    // 获取子级栏目id
    public function childrenIDs($cateID,$obj) {
        $data = $obj->field('id,pid')->select();
        return $this->_childrenIDs($data,$cateID,TRUE);
    }

    public function _childrenIDs($data,$cateID,$clear=FALSE) {
        static $arr = [];
        if ($clear) {
            $arr = [];
        }
        foreach ($data as $k => $v) {
            if ($v['pid'] == $cateID) {
                $arr[] = $v['id'];
                $this->_childrenIDs($data,$v['id']);
            }
        }
        return $arr;
    }

    // 排序
    public function cateSort($data,$obj) {
        foreach ($data as $k => $v) {
            $obj->update(['id'=>$k,'sort'=>$v]);
        }
    }
}