/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 * user_passport.dwt 验证提交
 */

// $('#registsubmit').submit().click(function() {
// 	var username = $("input[name='username']").val();
// 	var password = $("input[name='password']").val();
// 	var email = $("#input[name='email']").val();
// 	var mobile_phone = $("input[name='mobile_phone']").val();
// 	var register_type = $("input[name='mobileagreement']").val();
// 	// alert(username);
// 	$.ajax({
// 		url : register_user,
// 		data : {
// 			username:username,
// 			password:password,
// 			email:email,
// 			mobile_phone:mobile_phone,
// 			register_type:register_type
// 		},
// 		dataType : 'json',
// 		type : 'post',
// 		success : function(res) {
// 			if (res.code == '1') {
// 				alert(res.msg);
// 			} else {
// 				alert(res.msg);
// 			}
// 		}
// 	});
// 	return false;
// });

$(function(){
	//注册页面验证
	$("#registsubmit").click(function(){
		// 是一个名为 valid 的功能函数，回传 true 或是 false，作用是检查 #myform 物件是否验证成功
		if($("form[name='formUser']").valid()){
			$("form[name='formUser']").submit();
		}
		return false;
	});

	// 下面的message就是启用了表单验证
	$("form[name='formUser']").validate({
		// 在被验证的控件的后一个元素控制显示
		errorPlacement:function(error, element){
			var error_div = element.parents('div.item').find('div.input-tip');
			error_div.html("").append(error);
		},
		ignore:".ignore",
		// 验证规则
		rules:{
			// 用户名验证
			username :{
				required : true,
				maxlength: 15,
				StringLength: true,
				remote : {
					cache: false,
					async:false,
					type:'POST',
					url:user_validate,
					data:{
						username:function(){
							return $("input[name='username']").val();
						}
					}
				}
			},
			password :{
				required : true,
				minlength: 6
			},
			confirm_password :{
				required : true,
				equalTo : "#pwd"
			},
			// 手机号验证
			mobile_phone:{
				required : true,
				isMobile : true,
				notequalTo:"#username",
				remote : {
					cache: false,
					async:false,
					type:'POST',
					url:check_phone,
					data:{
						mobile_phone:function(){
							return $("input[name='mobile_phone']").val();
						}
					}
				}
			},
			captcha:{
				required : true,
				remote : {
					cache: false,
					async:false,
					type:'POST',
					url:'user.php?act=phone_captcha',
					data:{
						captcha:function(){
							return $("input[name='captcha']").val();
						}
					},
					dataFilter:function(data,type){
						if(data == "false"){
							$("input[name='captcha']").siblings(".captcha_img").click();
						}
						return data;
					}
				}
			},
			// 验证手机code
			mobile_code :{
				required : true,
				remote : {
					cache: false,
					async:false,
					type:'POST',
					url:check_phone_code,
					data:{
						mobile_code:function(){
							return $("input[name='mobile_code']").val();
						}
					}
				}
			},
			// 邮箱验证
			email:{
				required : true,
				email:true,
				remote : {
					cache: false,
					async:false,
					type:'POST',
					url:check_email,
					data:{
						email:function(){
							return $("input[name='email']").val();
						}
					}
				}
			},
			mobileagreement : {
				required : true
			},
			// 验证邮箱code
			send_code : {
				required : true,
				remote : {
					cache: false,
					async:false,
					type:'POST',
					url:check_email_code,
					data:{
						send_code:function(){
							return $("input[name='send_code']").val();
						}
					}
				}
			},
			sel_question:{
				required : true
			},
			passwd_answer:{
				required : true
			}
		},
		// 验证规则返回信息
		messages:{
			username:{
				required : username_empty,
				maxlength: msg_un_length,
				StringLength: username_shorter,
				remote : msg_un_registered
			},
			password :{
				required : password_empty,
				minlength : password_shorter
			},
			confirm_password :{
				required : msg_confirm_pwd_blank,
				equalTo : confirm_password_invalid
			},
			mobile_phone:{
				required : msg_phone_blank,
				isMobile : mobile_phone_invalid,
				notequalTo : mobile_phone_username_equalTo,
				remote : msg_phone_registered
			},
			captcha :{
				required : msg_identifying_code,
				remote : msg_identifying_not_correct
			},
			mobile_code :{
				required : msg_mobile_code_blank,
				remote : msg_mobile_code_not_correct
			},
			email :{
				required : msg_email_blank,
				email : msg_email_format,
				remote : msg_email_registered
			},
			mobileagreement:{
				required : agreement
			},
			send_code :{
				required : msg_email_code,
				remote : msg_email_code_not
			},
			sel_question :{
				required : select_password_question
			},
			passwd_answer:{
				required : null_password_question
			}
		},

		success:function(label){
			label.removeClass().addClass("succeed").html("<i></i>");
		},
		onkeyup:function(element,event){
			var name = $(element).attr("name");

			var strongRegex = new RegExp("^(?=.{8,})(?=.*[A-Z])(?=.*[a-z])(?=.*[0-9])(?=.*\\W).*$", "g");
			var mediumRegex = new RegExp("^(?=.{7,})(((?=.*[A-Z])(?=.*[a-z]))|((?=.*[A-Z])(?=.*[0-9]))|((?=.*[a-z])(?=.*[0-9]))).*$", "g");

			if(name == "password"){
				if(strongRegex.test($(element).val())){
					$(element).parents(".item-info").next(".input-tip").html("<div class='strength strengthC'><b></b><span>强</span></div>");
				}else if(mediumRegex.test($(element).val())){
					$(element).parents(".item-info").next(".input-tip").html("<div class='strength strengthB'><b></b><span>中</span></div>");
				}else{
					$(element).parents(".item-info").next(".input-tip").html("<div class='strength strengthA'><b></b><span>弱</span></div>");
				}
			}else if(name == "captcha"){
				//不可去除，当是验证码输入必须失去焦点才可以验证（错误刷新验证码）
				return true;
			}
		}
	});

	//找回密码验证
	$("*[ectype='submitBtn']").click(function(){
		var formName = $(this).parents("*[ectype='form']").attr("name"); //form表单name值
		var form = $("form[name='"+formName+"']");
		var seKey = form.find("img[name='img_captcha']").data("key"); //验证码key值

		$("form[name='"+formName+"']").validate({
			errorPlacement:function(error, element){
				var error_div = element.parents('div.item').find('div.input-tip');
				error_div.html("").append(error);
			},
			ignore : ".ignore"
		});

		if(formName != 'getPhonePassword'){
			//用户名验证
			form.find("input[name='user_name']").rules("add",{
				required : true,
				messages : {
					required : null_username
				}
			});
		}

		//手机号码验证
		form.find("input[name='mobile_phone']").rules("add",{
			required : true,
			messages : {
				required : null_phone
			}
		});

		//手机短信验证码
		form.find("input[name='mobile_code']").rules("add",{
			required : true,
			remote : {
				cache: false,
				async:false,
				type:'POST',
				url:check_new_hone_code,
				data:{
					mobile_code:function(){
						return $("input[name='mobile_code']").val();
					}
				}
			},
			messages : {
				required : msg_mobile_code_blank,
				remote : msg_mobile_code_not_correct
			}
		});

		//验证码验证
		form.find("input[name='captcha']").rules("add",{
			required : true,
			remote : {
				cache: false,
				async:false,
				type:'POST',
				url:'user.php?act=captchas_pass&seKey='+seKey,
				data:{
					captcha:function(){
						return form.find("input[name='captcha']").val();
					},
					dataFilter:function(data,type){
						if(data == "false"){
							form.find("input[name='captcha']").siblings(".captcha_img").click();
						}
						return data;
					}
				}
			},
			messages : {
				required : msg_identifying_code,
				remote : msg_identifying_not_correct
			}
		});

		//邮箱账号
		form.find("input[name='email']").rules("add",{
			required : true,
			email : true,
			messages : {
				required : msg_email_blank,
				email : msg_email_format
			}
		});

		//密码提示问题选择
		form.find("input[name='sel_question']").rules("add",{
			required : true,
			messages : {
				required : select_password_question
			}
		});

		//密码提示问题答案
		form.find("input[name='passwd_answer']").rules("add",{
			required : true,
			messages : {
				required : null_password_question
			}
		});

		//新密码
		form.find("input[name='new_password']").rules("add",{
			required : true,
			minlength: 6,
			messages : {
				required : new_password_empty,
				minlength : password_shorter
			}
		});

		//确认新密码
		form.find("input[name='confirm_password']").rules("add",{
			required : true,
			equalTo : "#pwd",
			messages : {
				required : confirm_password_empty,
				equalTo : both_password_error
			}
		});
	});
});




function sendChangePhone() {
	var phone = $("input[name='mobile_phone']").val();
	$.ajax({
		url : phone_url,
		data : {phone:phone},
		type : 'POST',
		dataType : 'JSON',
		success : function(res) {
			if (res.code == 0) {
				// 信息发送成功，设置cookie并调用倒计时
				$.cookie('totalP',60);
				$('#zphone').val(res.msg);
				timekeepingPhone();
			} else if (res.code == 1) {
				$('#zphone').val(res.msg);
			} else {
				$('#zphone').val(res.msg);
			}
		}
	})
}

// 找回密码
function sendSms() {
	var phone = $("input[name='mobile_phone']").val();
	$.ajax({
		url : check_phone_msg,
		data : {phone:phone},
		type : 'POST',
		dataType : 'JSON',
		success : function(res) {

			if (res.code == 0) {
				// 信息发送成功，设置cookie并调用倒计时
				$.cookie('totalP',60);
				$('#zphone').val(res.msg);
				$('#phone_notice').html(res.msg);
				timekeepingPhone();
			} else if (res.code == 1) {
				$('#phone_notice').html(res.msg);
			} else {
				$('#phone_notice').html(res.msg);
			}
		}
	})
}


// 写入手机cookie倒计时
function timekeepingPhone() {
	// 执行到这个函数,按钮为禁用状态
	$('#zphone').attr('disabled',true);
	// setInterval() 方法会不停地调用函数
	var interval = setInterval(function(){
		total = $.cookie('totalP');
		$('#zphone').val(""+total+"s 重新发送");
		total--;
		if (total == 0) {
			// clearInterval() 方法可取消由 setInterval() 函数设定的定时执行操作。
			clearInterval(interval);
			$.cookie('totalP',total,{expires : -1});
			$('#zphone').val('获取验证码');
			$('#zphone').attr('disabled',false);
		} else {
			$.cookie('totalP',total);
		}
	},1000);
}


//获取邮箱验证码
function sendChangeEmail() {
	var email = $("input[name='email']").val();
	$.ajax({
		url : email_url,
		data : {email:email},
		type : 'POST',
		dataType : 'JSON',
		success : function(res) {
			if (res.code == 0) {
				// 邮箱发送成功，设置cookie并调用倒计时
				$.cookie('totalE',60);
				$('#zemail').val(res.msg);
				timekeepingEmail();
			} else {
				$('#zemail').val(res.msg);
			}
		}
	})
}

// 写入邮箱cookie倒计时
function timekeepingEmail() {
	// 执行到这个函数,按钮为禁用状态
	$('#zemail').attr('disabled',true);
	// setInterval() 方法会不停地调用函数
	var interval = setInterval(function(){
		total = $.cookie('totalE');
		$('#zemail').val(""+total+"s 重新发送");
		total--;
		if (total == 0) {
			// clearInterval() 方法可取消由 setInterval() 函数设定的定时执行操作。
			clearInterval(interval);
			$.cookie('totalE',total,{expires : -1});
			$('#zemail').val('获取验证码');
			$('#zemail').attr('disabled',false);
		} else {
			$.cookie('totalE',total);
		}
	},1000);
}



// 写入找回密码手机cookie倒计时
// function timekeepingPhoneSms() {
// 	// 执行到这个函数,按钮为禁用状态
// 	$('#phone').attr('disabled',true);
// 	// setInterval() 方法会不停地调用函数
// 	var interval = setInterval(function(){
// 		total = $.cookie('totalM');
// 		$('#phone').val(""+total+"s 重新发送");
// 		total--;
// 		if (total == 0) {
// 			// clearInterval() 方法可取消由 setInterval() 函数设定的定时执行操作。
// 			clearInterval(interval);
// 			$.cookie('totalM',total,{expires : -1});
// 			$('#phone').val('获取验证码');
// 			$('#phone').attr('disabled',false);
// 		} else {
// 			$.cookie('totalM',total);
// 		}
// 	},1000);
// }






// 普通倒计时
function invokeSettime(obj) {
	var countdown = 60;
	settime(obj);
	function settime(obj) {
		if (countdown == 0) {
			$(obj).attr('disabled',false);
			$(obj).val('获取验证码');
			countdown = 60;
			return;
		} else {
			$(obj).attr('disabled',true);
			$(obj).val(""+countdown+"s 重新发送");
			countdown--;
		}
		setTimeout(function(){
			settime(obj)
		},1000)
	}
}





// function sendChangeEmail(type){
// 	var obj = $("input[name='email']"),
// 		email = obj.val(),
// 		where = "";
//
// 	if(!type){
// 		type = 0;
// 	}
//
// 	if(email != ""){
// 		where = "&email=" + email;
// 	}else{
// 		obj.parents("#code_email").find(".input-tip").html("<label class='error'>" + msg_email_blank + "</label>");
// 	}
//
// 	Ajax.call( 'user.php?act=user_email_send', 'type=' + type + where, function(result){
// 		if(result.replace(/\r\n/g,'') == 'ok'){
// 			pbDialog(json_languages.Mailbox_sent,"",1);
// 		}
// 	} , 'GET', 'TEXT', true, true );
// }