$(function() {
    $.ajax({
        url : check_log,
        dataType : 'json',
        type : 'get',
        success : function(res) {
            if (res.code == 0) {
                var htmls = "<span>您好 &nbsp;<a href='#'>"+res.username+"</a></span>"+
                    "<span>，欢迎来到&nbsp;<a alt='首页' title='首页' href='/'>淘味商城</a></span>&nbsp;"+
                    "<span>[<a onclick='loginOut()' href=''>退出</a>]</span>"+
                    "<div class='scrollBody' id='scrollBody'></div>";
                $('#ECS_MEMBERZONE').html(htmls);
            } else {
                var  htmls = "<a href='"+login_go+"' class='link-login red'>请登录</a>"+
                    "<a href='"+register_go+"' class='link-regist'>免费注册</a>"+
                    "<div class='scrollBody' id='scrollBody'></div>";
                $('#ECS_MEMBERZONE').html(htmls);
            }
        }
    })
    cartGoodsNum();
});

function cartGoodsNum() {
    $(function(){
        $.ajax({
            url : cart_goods_num,
            dataType : 'json',
            type : 'POST',
            success : function(res) {
                $('#cart_goods_num').text(res.cartGoodsNum)
            }
        })
    })
}

function loginOut() {
    $.ajax({
        url : login_out,
        dataType: 'json',
        type : 'get',
        success : function(res) {
            if (res.code == 0) {
                alert(res.msg);
                location.href('/');
            } else {
                alert(res.msg);
            }
        }
    });
}

