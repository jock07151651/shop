<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:78:"D:\phpstudy_pro\WWW\shop\public/../application/index\view\common\tip_info.html";i:1597736439;s:76:"D:\phpstudy_pro\WWW\shop\public/../application/index\view\common\header.html";i:1597735806;s:76:"D:\phpstudy_pro\WWW\shop\public/../application/index\view\common\footer.html";i:1597670431;}*/ ?>


<!doctype html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="Keywords" content="大商创 免费商城系统 免费B2B2C 免费多商户系统  多店铺商城系统 企业级电商系统  ecsho" />
    <meta name="Description" content="大商创是由商创网络（模板堂）推出的免费B2B2C商城系统，支持多店铺入驻，包含多城市多仓库等众多功能，能帮助企业及个人快速搭建多商户电商系统，并减少二次开发带来的成本" />

    <title>购物流程_大商创-免费B2B2C商城系统，免费多商户商城系统，多店铺商城系统，企业级电商系统免费下载_模板堂出</title>



    <link rel="shortcut icon" href="favicon.ico" />
    <link rel="stylesheet" type="text/css" href="__INDEX__/css/base.css" />
    <link rel="stylesheet" type="text/css" href="__INDEX__/css/style.css" />
    <link rel="stylesheet" type="text/css" href="__INDEX__/css/iconfont.css" />
    <link rel="stylesheet" type="text/css" href="__INDEX__/css/purebox.css" />
    <link rel="stylesheet" type="text/css" href="__INDEX__/css/quickLinks.css" />

    <script type="text/javascript" src="__INDEX__/js/jquery-1.9.1.min.js"></script>
    <script type="text/javascript" src="__INDEX__/js/jquery.json.js"></script>
    <script type="text/javascript" src="__INDEX__/js/transport_jquery.js"></script>
    <script type="text/javascript">
        var json_languages = {"ok":"\u786e\u5b9a","determine":"\u786e\u5b9a","cancel":"\u53d6\u6d88","drop":"\u5220\u9664","edit":"\u7f16\u8f91","remove":"\u79fb\u9664","follow":"\u5173\u6ce8","pb_title":"\u63d0\u793a","Prompt_information":"\u63d0\u793a\u4fe1\u606f","title":"\u63d0\u793a","not_login":"\u60a8\u5c1a\u672a\u767b\u5f55","close":"\u5173\u95ed","cart":"\u8d2d\u7269\u8f66","js_cart":"\u8d2d\u7269\u8f66","all":"\u5168\u90e8","go_login":"\u53bb\u767b\u9646","select_city":"\u8bf7\u9009\u62e9\u5e02","comment_goods":"\u8bc4\u8bba\u5546\u54c1","submit_order":"\u63d0\u4ea4\u8ba2\u5355","sys_msg":"\u7cfb\u7edf\u63d0\u793a","no_keywords":"\u8bf7\u8f93\u5165\u641c\u7d22\u5173\u952e\u8bcd\uff01","adv_packup_one":"\u8bf7\u53bb\u540e\u53f0\u5e7f\u544a\u4f4d\u7f6e","adv_packup_two":"\u91cc\u9762\u8bbe\u7f6e\u5e7f\u544a\uff01","more":"\u66f4\u591a","Please":"\u8bf7\u53bb","set_up":"\u8bbe\u7f6e\uff01","login_phone_packup_one":"\u8bf7\u8f93\u5165\u624b\u673a\u53f7\u7801","more_options":"\u66f4\u591a\u9009\u9879","Pack_up":"\u6536\u8d77","no_attr":"\u6ca1\u6709\u66f4\u591a\u5c5e\u6027\u4e86","search_Prompt":"\u53ef\u8f93\u5165\u6c49\u5b57,\u62fc\u97f3\u67e5\u627e\u54c1\u724c","most_input":"\u6700\u591a\u53ea\u80fd\u9009\u62e95\u9879","multi_select":"\u591a\u9009","checkbox_Packup":"\u8bf7\u6536\u8d77\u5168\u90e8\u591a\u9009","radio_Packup":"\u8bf7\u6536\u8d77\u5168\u90e8\u5355\u9009","contrast":"\u5bf9\u6bd4","empty_contrast":"\u6e05\u7a7a\u5bf9\u6bd4\u680f","Prompt_add_one":"\u6700\u591a\u53ea\u80fd\u6dfb\u52a04\u4e2a\u54e6^_^","Prompt_add_two":"\u60a8\u8fd8\u53ef\u4ee5\u7ee7\u7eed\u6dfb\u52a0","button_compare":"\u6bd4\u8f83\u9009\u5b9a\u5546\u54c1","exist":"\u60a8\u5df2\u7ecf\u9009\u62e9\u4e86%s","count_limit":"\u6700\u591a\u53ea\u80fd\u9009\u62e94\u4e2a\u5546\u54c1\u8fdb\u884c\u5bf9\u6bd4","goods_type_different":"%s\u548c\u5df2\u9009\u62e9\u5546\u54c1\u7c7b\u578b\u4e0d\u540c\u65e0\u6cd5\u8fdb\u884c\u5bf9\u6bd4","compare_no_goods":"\u60a8\u6ca1\u6709\u9009\u5b9a\u4efb\u4f55\u9700\u8981\u6bd4\u8f83\u7684\u5546\u54c1\u6216\u8005\u6bd4\u8f83\u7684\u5546\u54c1\u6570\u5c11\u4e8e 2 \u4e2a\u3002","btn_buy":"\u8d2d\u4e70","is_cancel":"\u53d6\u6d88","select_spe":"\u8bf7\u9009\u62e9\u5546\u54c1\u5c5e\u6027","Country":"\u8bf7\u9009\u62e9\u6240\u5728\u56fd\u5bb6","Province":"\u8bf7\u9009\u62e9\u6240\u5728\u7701\u4efd","City":"\u8bf7\u9009\u62e9\u6240\u5728\u5e02","District":"\u8bf7\u9009\u62e9\u6240\u5728\u533a\u57df","Street":"\u8bf7\u9009\u62e9\u6240\u5728\u8857\u9053","Detailed_address_null":"\u8be6\u7ec6\u5730\u5740\u4e0d\u80fd\u4e3a\u7a7a","consignee":"\u8bf7\u586b\u5199\u6536\u8d27\u4eba\u4fe1\u606f","Select_attr":"\u8bf7\u9009\u62e9\u5c5e\u6027","Focus_prompt_one":"\u60a8\u5df2\u5173\u6ce8\u8be5\u5e97\u94fa\uff01","Focus_prompt_login":"\u60a8\u5c1a\u672a\u767b\u5f55\u5546\u57ce\u4f1a\u5458\uff0c\u4e0d\u80fd\u5173\u6ce8\uff01","Focus_prompt_two":"\u767b\u5f55\u5546\u57ce\u4f1a\u5458\u3002","store_focus":"\u5e97\u94fa\u5173\u6ce8\u3002","Focus_prompt_three":"\u60a8\u786e\u5b9e\u8981\u5173\u6ce8\u6240\u9009\u5e97\u94fa\u5417\uff1f","Focus_prompt_four":"\u60a8\u786e\u5b9e\u8981\u53d6\u6d88\u5173\u6ce8\u5e97\u94fa\u5417\uff1f","Focus_prompt_five":"\u60a8\u8981\u5173\u6ce8\u8be5\u5e97\u94fa\u5417\uff1f","Purchase_quantity":"\u8d85\u8fc7\u9650\u8d2d\u6570\u91cf.","My_collection":"\u6211\u7684\u6536\u85cf","shiping_prompt":"\u6682\u4e0d\u652f\u6301\u914d\u9001","Have_goods":"\u6709\u8d27","No_goods":"\u5f88\u62b1\u6b49\uff0c\u65e0\u8d27\u5566","No_shipping":"\u5f88\u62b1\u6b49\uff0c\u65e0\u6cd5\u914d\u9001","Deliver_back_order":"\u4e0b\u5355\u540e\u7acb\u5373\u53d1\u8d27","Time_delivery":" \u65f6\u53d1\u8d27","goods_over":"\u6b64\u5546\u54c1\u6682\u65f6\u552e\u5b8c","Stock_goods_null":"\u5546\u54c1\u5e93\u5b58\u4e0d\u8db3","purchasing_prompt_two":"\u5bf9\u4e0d\u8d77\uff0c\u8be5\u5546\u54c1\u5df2\u7ecf\u7d2f\u8ba1\u8d85\u8fc7\u9650\u8d2d\u6570\u91cf","day_not_available":"\u5f53\u65e5\u65e0\u8d27","day_yes_available":"\u5f53\u65e5\u6709\u8d27","Already_buy":"\u5df2\u8d2d\u4e70","Already_buy_two":"\u4ef6\u5546\u54c1\u8fbe\u5230\u9650\u8d2d\u6761\u4ef6,\u65e0\u6cd5\u518d\u8d2d\u4e70","Already_buy_three":"\u4ef6\u8be5\u5546\u54c1,\u53ea\u80fd\u518d\u8d2d\u4e70","goods_buy_empty_p":"\u5546\u54c1\u6570\u91cf\u4e0d\u80fd\u5c11\u4e8e1\u4ef6","goods_number_p":"\u5546\u54c1\u6570\u91cf\u5fc5\u987b\u4e3a\u6570\u5b57","search_one":"\u8bf7\u586b\u5199\u7b5b\u9009\u4ef7\u683c","search_two":"\u8bf7\u586b\u5199\u7b5b\u9009\u5de6\u8fb9\u4ef7\u683c","search_three":"\u8bf7\u586b\u5199\u7b5b\u9009\u53f3\u8fb9\u4ef7\u683c","search_four":"\u5de6\u8fb9\u4ef7\u683c\u4e0d\u80fd\u5927\u4e8e\u6216\u7b49\u4e8e\u53f3\u8fb9\u4ef7\u683c","jian":"\u4ef6","letter":"\u4ef6","inventory":"\u5b58\u8d27","move_collection":"\u79fb\u81f3\u6211\u7684\u6536\u85cf","select_shop":"\u8bf7\u9009\u62e9\u5957\u9910\u5546\u54c1","Parameter_error":"\u53c2\u6570\u9519\u8bef","screen_price":"\u8bf7\u586b\u5199\u7b5b\u9009\u4ef7\u683c","screen_price_left":"\u8bf7\u586b\u5199\u7b5b\u9009\u5de6\u8fb9\u4ef7\u683c","screen_price_right":"\u8bf7\u586b\u5199\u7b5b\u9009\u53f3\u8fb9\u4ef7\u683c","screen_price_dy":"\u5de6\u8fb9\u4ef7\u683c\u4e0d\u80fd\u5927\u4e8e\u6216\u7b49\u4e8e\u53f3\u8fb9\u4ef7\u683c","invoice_ok":"\u4fdd\u5b58\u53d1\u7968\u4fe1\u606f","invoice_desc_null":"\u8f93\u5165\u5185\u5bb9\u4e0d\u80fd\u4e3a\u7a7a\uff01","invoice_desc_number":"\u60a8\u6700\u591a\u53ef\u4ee5\u6dfb\u52a03\u4e2a\u516c\u53f8\u53d1\u7968\uff01","invoice_packup":"\u8bf7\u9009\u62e9\u6216\u586b\u5199\u53d1\u7968\u62ac\u5934\u90e8\u5206\uff01","invoice_tax_null":"\u8bf7\u586b\u5199\u7eb3\u7a0e\u4eba\u8bc6\u522b\u7801","add_address_10":"\u6700\u591a\u53ea\u80fd\u6dfb\u52a010\u4e2a\u6536\u8d27\u5730\u5740","msg_phone_not":"\u624b\u673a\u53f7\u7801\u4e0d\u6b63\u786e","msg_phone_blank":"\u624b\u673a\u53f7\u7801\u4e0d\u80fd\u4e3a\u7a7a","captcha_not":"\u9a8c\u8bc1\u7801\u4e0d\u80fd\u4e3a\u7a7a","captcha_xz":"\u8bf7\u8f93\u51654\u4f4d\u6570\u7684\u9a8c\u8bc1\u7801","captcha_cw":"\u9a8c\u8bc1\u7801\u9519\u8bef","Detailed_map":"\u8be6\u7ec6\u5730\u56fe","email_error":"\u90ae\u7bb1\u683c\u5f0f\u4e0d\u6b63\u786e\uff01","bid_prompt_null":"\u4ef7\u683c\u4e0d\u80fd\u4e3a\u7a7a!","bid_prompt_error":"\u4ef7\u683c\u8f93\u5165\u683c\u5f0f\u4e0d\u6b63\u786e\uff01","mobile_error_goods":"\u624b\u673a\u683c\u5f0f\u4e0d\u6b63\u786e\uff01","null_email_goods":"\u90ae\u7bb1\u4e0d\u80fd\u4e3a\u7a7a","select_store":"\u8bf7\u9009\u62e9\u95e8\u5e97\uff01","Product_spec_prompt":"\u8bf7\u9009\u62e9\u5546\u54c1\u89c4\u683c\u7c7b\u578b","reply_desc_one":"\u56de\u590d\u5e16\u5b50\u5185\u5bb9\u4e0d\u80fd\u4e3a\u7a7a","go_shoping":"\u53bb\u8d2d\u7269","loading":"\u6b63\u5728\u62fc\u547d\u52a0\u8f7d\u4e2d...","purchasing_minamount":"\u5bf9\u4e0d\u8d77\uff0c\u8d2d\u4e70\u6570\u91cf\u4e0d\u80fd\u5c0f\u4e8e\u6700\u5c0f\u9636\u68af\u4ef7","no_history":"\u60a8\u5df2\u6e05\u7a7a\u6700\u8fd1\u6d4f\u89c8\u8fc7\u7684\u5546\u54c1","receive_coupons":"\u9886\u53d6\u4f18\u60e0\u5238","Immediate_use":"\u7acb\u5373\u4f7f\u7528","no_enabled":"\u5173\u95ed","highest_price":"\u5df2\u662f\u6700\u9ad8\u4ef7\uff01","lowest_price":"\u5df2\u662f\u6700\u4f4e\u4ef7\uff01","Purchase_restrictions":"\u8d2d\u4e70\u6570\u91cf\u4e0d\u80fd\u5c11\u4e8e1\u4ef6","remove_checked_goods":"\u5220\u9664\u9009\u4e2d\u7684\u5546\u54c1","go_up":"\u7ee7\u7eed","back_cart":"\u8fd4\u56de\u8d2d\u7269\u8f66","save":"\u4fdd\u5b58","delivery_Prompt":"\u8be5\u533a\u57df\u6ca1\u6709\u63d0\u8d27\u70b9!","delivery_Prompt_two":"\u8bf7\u9009\u62e9\u63d0\u8d27\u65f6\u95f4\u6bb5!","checked_address":"\u8bf7\u9009\u62e9\u6536\u8d27\u5730\u5740!","no_store":"\u8be5\u5730\u533a\u6ca1\u6709\u95e8\u5e97!","buy_more":"\u6700\u591a\u9886\u53d6","a_goods":"\u4e2a\u5546\u54c1","drop_goods":"\u5220\u9664\u5546\u54c1\uff1f","drop_desc":"\u60a8\u53ef\u4ee5\u9009\u62e9\u79fb\u5230\u6536\u85cf\uff0c\u6216\u5220\u9664\u5546\u54c1\u3002","Move_collection":"\u79fb\u5230\u6536\u85cf","Move_desc":"\u79fb\u52a8\u540e\u9009\u4e2d\u5546\u54c1\u5c06\u4e0d\u5728\u8d2d\u7269\u8f66\u4e2d\u663e\u793a\u3002","confirm_default_address":"\u60a8\u786e\u5b9a\u8981\u8bbe\u7f6e\u4e3a\u9ed8\u8ba4\u6536\u8d27\u5730\u5740\u5417\uff1f","confirm_drop_address":"\u60a8\u786e\u5b9a\u8981\u5220\u9664\u8be5\u6536\u8d27\u5730\u5740\u5417\uff1f","please_checked_address":"\u60a8\u8fd8\u6ca1\u6709\u9009\u62e9\u6536\u8d27\u5730\u5740\uff01","cart_empty_goods":"\u60a8\u7684\u8d2d\u7269\u8f66\u4e2d\u6ca1\u6709\u5546\u54c1\uff01","confirm_Move_collection":"\u79fb\u52a8\u540e\u9009\u4e2d\u5546\u54c1\u5c06\u4e0d\u5728\u8d2d\u7269\u8f66\u4e2d\u663e\u793a\uff01","Shipping_address":"\u6536\u8d27\u5730\u5740","add_shipping_address":"\u6dfb\u52a0\u6536\u8d27\u5730\u5740","no_delivery":"\u6682\u4e0d\u652f\u6301\u8be5\u5730\u533a\u914d\u9001\u3002","delivery_information":"\u914d\u9001\u4fe1\u606f","pay_password_packup_null":"\u652f\u4ed8\u5bc6\u7801\u4e0d\u80fd\u4e3a\u7a7a\uff01","pay_password_packup_error":"\u60a8\u7684\u652f\u4ed8\u5bc6\u7801\u6709\u8bef\uff01","flow_no_payment":"\u60a8\u5fc5\u987b\u9009\u5b9a\u4e00\u4e2a\u652f\u4ed8\u65b9\u5f0f","flow_no_shipping":"\u60a8\u5fc5\u987b\u9009\u5b9a\u4e00\u4e2a\u914d\u9001\u65b9\u5f0f","Mobile_error":"\u624b\u673a\u53f7\u683c\u5f0f\u4e0d\u6b63\u786e\uff01","phone_error":"\u7535\u8bdd\u53f7\u7801\u683c\u5f0f\u4e0d\u6b63\u786e\uff01","order_detail":"\u8ba2\u5355\u8be6\u60c5","down_detail":"\u6536\u8d77\u8be6\u60c5","payTitle":"\u6b63\u5728\u652f\u4ed8","select_consigne":"\u8bf7\u9009\u62e9\u6240\u5728\u56fd\u5bb6","consignee_legitimate_email":"\u60a8\u8f93\u5165\u7684\u90ae\u4ef6\u5730\u5740\u4e0d\u662f\u4e00\u4e2a\u5408\u6cd5\u7684\u90ae\u4ef6\u5730\u5740","consignee_legitimate_phone":"\u624b\u673a\u53f7\u7801\u4e0d\u5408\u6cd5","input_Consignee_name":"\u8bf7\u60a8\u586b\u5199\u6536\u8d27\u4eba\u59d3\u540d","con_Preservation":"\u4fdd\u5b58\u6536\u8d27\u4eba\u4fe1\u606f","Preservation":"\u4fdd\u5b58","add_invoice":"\u65b0\u589e\u5355\u4f4d\u53d1\u7968","checked_goods_number":"\u8bf7\u52fe\u9009\u4e2d\u5546\u54c1\u5728\u4fee\u6539\u5546\u54c1\u6570\u91cf","not_seller_batch_goods_num":"\u8bf7\u52fe\u9009\u4e2d\u5546\u54c1\u5728\u4fee\u6539\u5546\u54c1\u6570\u91cf","payment_is_online":"\u5728\u7ebf\u652f\u4ed8"};

        //加载效果
        var load_cart_info = '<img src="themes/ecmoban_dsc2017/images/load/loadGoods.gif" class="load" />';
        var load_icon = '<img src="themes/ecmoban_dsc2017/images/load/load.gif" width="200" height="200" />';
    </script><link rel="stylesheet" type="text/css" href="js/perfect-scrollbar/perfect-scrollbar.min.css" />
</head>

<body class="bg-ligtGary">

<div class="site-nav" id="site-nav">
    <div class="w w1390">
        <div class="fl">
            <div class="txt-info" id="ECS_MEMBERZONE">
                <div class='scrollBody' id='scrollBody'></div>
            </div>
        </div>
        <ul class="quick-menu fr">
            <?php if(is_array($navList['top']) || $navList['top'] instanceof \think\Collection || $navList['top'] instanceof \think\Paginator): $i = 0; $__LIST__ = $navList['top'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$top_list): $mod = ($i % 2 );++$i;?>
            <li>
                <div class="dt">
                    <a href="<?php echo $top_list['nav_url']; ?>" <?php if($top_list['open'] == 1): ?> target="_bank" <?php endif; ?>>
                    <?php echo $top_list['nav_name']; ?>
                    </a>
                </div>
            </li>
            <?php endforeach; endif; else: echo "" ;endif; ?>
        </ul>
    </div>
</div>

<div class="header">
    <div class="w w1390">
        <div class="logo">
            <div class="logoImg"><a href="/"><img src="__INDEX__/img/logo.png"/></a></div>
        </div>
        <div class="dsc-search">
            <div class="form">
                <form id="searchForm" name="searchForm" method="get" action="search.php"
                      onSubmit="return checkSearchForm()" class="search-form">
                    <input autocomplete="off" onKeyUp="lookup(this.value);" name="keywords" type="text" id="keyword"
                           value="内衣" class="search-text"/>
                    <input type="hidden" name="store_search_cmt" value="0">
                    <button type="submit" class="button button-goods" onclick="checkstore_search_cmt(0)">搜商品</button>
                </form>
                <ul class="keyword">
                    <li><a href="#" target="_blank">周大福</a></li>
                    <li><a href="#" target="_blank">内衣</a></li>
                    <li><a href="#" target="_blank">Five Plus</a></li>
                    <li><a href="#" target="_blank">手机</a></li>
                </ul>

                <div class="suggestions_box" id="suggestions" style="display:none;">
                    <div class="suggestions_list" id="auto_suggestions_list">
                        &nbsp;
                    </div>
                </div>

            </div>
        </div>
        <div class="shopCart" data-ectype="dorpdown" id="ECS_CARTINFO" data-carteveval="0">

            <div class="shopCart-con dsc-cm">
                <a href="#">
                    <i class="iconfont icon-carts"></i>
                    <span>我的购物车</span>
                    <em class="count cart_num">0</em>
                </a>
            </div>
            <div class="dorpdown-layer" ectype="dorpdownLayer">
                <div class="prompt">
                    <div class="nogoods"><b></b><span>购物车中还没有商品，赶紧选购吧！</span></div>
                </div>
            </div>
            <script type="text/javascript">
                // 1. ajax异步获取顶级分类下的子分类、品牌、频道等相关信息在右侧菜单显示
                var ajax_cate_url = "<?php echo url('index/Category/getCategoryInfo'); ?>";
                // 2. 加载中gif图片 路径
                var load_img = "__INDEX__/img/loadGoods.gif";
                // 上面自定义
                function changenum(rec_id, diff, warehouse_id, area_id) {
                    var cValue = $('#cart_value').val();
                    var goods_number = Number($('#goods_number_' + rec_id).text()) + Number(diff);

                    if (goods_number < 1) {
                        return false;
                    } else {
                        change_goods_number(rec_id, goods_number, warehouse_id, area_id, cValue);
                    }
                }

                function change_goods_number(rec_id, goods_number, warehouse_id, area_id, cValue) {
                    if (cValue != '' || cValue == 'undefined') {
                        var cValue = $('#cart_value').val();
                    }
                    Ajax.call('flow.php?step=ajax_update_cart', 'rec_id=' + rec_id + '&goods_number=' + goods_number + '&cValue=' + cValue + '&warehouse_id=' + warehouse_id + '&area_id=' + area_id, change_goods_number_response, 'POST', 'JSON');
                }

                function change_goods_number_response(result) {
                    var rec_id = result.rec_id;
                    if (result.error == 0) {
                        $('#goods_number_' + rec_id).val(result.goods_number);//更新数量
                        $('#goods_subtotal_' + rec_id).html(result.goods_subtotal);//更新小计
                        if (result.goods_number <= 0) {
                            //数量为零则隐藏所在行
                            $('#tr_goods_' + rec_id).style.display = 'none';
                            $('#tr_goods_' + rec_id).innerHTML = '';
                        }
                        $('#total_desc').html(result.flow_info);//更新合计
                        if ($('ECS_CARTINFO'))


                            if (result.group.length > 0) {
                                for (var i = 0; i < result.group.length; i++) {
                                    $("#" + result.group[i].rec_group).html(result.group[i].rec_group_number);//配件商品数量
                                    $("#" + result.group[i].rec_group_talId).html(result.group[i].rec_group_subtotal);//配件商品金额
                                }
                            }

                        $("#goods_price_" + rec_id).html(result.goods_price);
                        $(".cart_num").html(result.subtotal_number);
                    } else if (result.message != '') {
                        $('#goods_number_' + rec_id).val(result.cart_Num);//更新数量
                        alert(result.message);
                    }
                }

                function deleteCartGoods(rec_id, index) {
                    Ajax.call('delete_cart_goods.php', 'id=' + rec_id + '&index=' + index, deleteCartGoodsResponse, 'POST', 'JSON');
                }

                /**
                 * 接收返回的信息
                 */
                function deleteCartGoodsResponse(res) {
                    if (res.error) {
                        alert(res.err_msg);
                    } else if (res.index == 1) {
                        // Ajax.call('get_ajax_content.php?act=get_content', 'data_type=cart_list', return_cart_list, 'POST', 'JSON');
                    } else {
                        $("#ECS_CARTINFO").html(res.content);
                        $(".cart_num").html(res.cart_num);
                    }
                }

                function return_cart_list(result) {
                    $(".cart_num").html(result.cart_num);
                    $(".pop_panel").html(result.content);
                    tbplHeigth();
                }
            </script>
        </div>
    </div>
</div>
<div class="nav dsc-zoom">
    <div class="w <?php if(isset($show_1200)){echo 'w1200';} else{echo 'w1390';}?>">
        <div class="categorys <?php if(!isset($show_site)){echo 'site-mast';} ?>">
            <div class="categorys-type"><a href="<?php echo url('Category/index'); ?>" target="_blank">全部商品分类</a></div>
            <div class="categorys-tab-content">
                <div class="categorys-items" id="cata-nav">
                    <!-- 菜单开始 -->
                    <?php if(is_array($categoryList) || $categoryList instanceof \think\Collection || $categoryList instanceof \think\Paginator): $i = 0; $__LIST__ = $categoryList;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$list): $mod = ($i % 2 );++$i;?>          <!-- data-id,再dsc-xx.js中起作用 -->
                    <div class="categorys-item" ectype="cateItem" data-id="<?php echo $list['id']; ?>" data-eveval="0">
                        <div class="item item-content">
                            <i class="iconfont <?php echo $list['iconfont']; ?>"></i>
                            <div class="categorys-title">
                                <strong><a href="<?php echo url('Category/index',array('id'=>$list['id'])); ?>" target="_blank"><?php echo $list['cate_name']; ?></a></strong>
                                <span>
                                    <?php if(is_array($list['child']) || $list['child'] instanceof \think\Collection || $list['child'] instanceof \think\Paginator): $i = 0; $__LIST__ = $list['child'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$list2): $mod = ($i % 2 );++$i;if($i < 3): ?>
                                    <a href="<?php echo url('Category/index',array('id'=>$list2['id'])); ?>" target="_blank"><?php echo $list2['cate_name']; ?></a>
                                    <?php endif; endforeach; endif; else: echo "" ;endif; ?>
                                </span>
                            </div>
                        </div>
                        <div class="categorys-items-layer" ectype="cateLayer">
                            <div class="cate-layer-con clearfix">
                                <div class="cate-layer-left">
                                    <div class="cate_channel" ectype="channels_<?php echo $list['id']; ?>"></div>
                                    <div class="cate_detail" ectype="subitems_<?php echo $list['id']; ?>"></div>
                                </div>
                                <div class="cate-layer-rihgt" ectype="brands_<?php echo $list['id']; ?>"></div>
                            </div>
                        </div>
                        <div class="clear"></div>
                    </div>
                    <?php endforeach; endif; else: echo "" ;endif; ?>
                    <!-- 菜单结束 -->
                </div>
            </div>
        </div>
        <div class="nav-main" id="nav">
            <ul class="navitems">
                <li><a href="/" class="curr">首页</a></li>
                <?php if(is_array($navList['mid']) || $navList['mid'] instanceof \think\Collection || $navList['mid'] instanceof \think\Paginator): $i = 0; $__LIST__ = $navList['mid'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$mid_list): $mod = ($i % 2 );++$i;?>
                <li>
                    <a href="<?php echo $mid_list['nav_url']; ?>" <?php if($mid_list['open'] == 1): ?> target="_bank" <?php endif; ?>>
                    <?php echo $mid_list['nav_name']; ?>
                    </a>
                </li>
                <?php endforeach; endif; else: echo "" ;endif; ?>
            </ul>
        </div>
    </div>
</div>


<div class="container">
    <div class="w w1200">

        <div class="payOrder-warp" id="pay_main">
            <div class="payOrder-desc">
                <div class="pay-top">

                    <div class="pay-total" >
                        <span>&nbsp;</span>
                        <div class="pay-price">&nbsp</div>
                    </div>
                </div>
                <div class="pay-txt">
                    <p><em id="nku">&nbsp</em></p>
                    <p><span id="paymode"></span><h3></h3></p>
                    <h3><?php echo $msg; ?></h3>
                </div>
                <div class="o-list">
                    <div class="o-list-info">
                        <span id="shdz">&nbsp</span>
                        <span id="shr">&nbsp</span>
                        <span id="mobile">&nbsp</span>
                    </div>
                </div>
                <a href="<?php echo url('member/Account/get_password'); ?>" class="orderPrint ftx-05">返回上一页</a>
            </div>

        </div>

    </div>
</div>
<div id="pay_Dialog" class="hide">
    <div class="pat">请您在新打开的支付页面进行支付，支付完成前请不要关闭该窗口</div>
    <div class="paydia-warp">
        <i></i>
        <div class="con">
            <div class="con-warp con-success">
                <h3>支付成功了</h3>
                <a href="user.php?act=order_list" class="ftx-05">订单详情></a>
            </div>
            <div class="con-warp con-fail">
                <h3>支付失败了</h3>
                <a href="article.php?id=17" class="ftx-05">支付遇到问题></a>
                <a href="index.php" class="ftx-05">继续购物></a>
            </div>
        </div>
    </div>
</div>




<div class="hide">

    <div id="dialog_remove" class="hide">
        <div class="tip-box icon-box">
            <span class="warn-icon m-icon"></span>
            <div class="item-fore">
                <h3 class="ftx-04">删除商品？</h3>
                <div class="ftx-03">您可以选择移到收藏，或删除商品。</div>
            </div>
        </div>
    </div>

    <div id="dialog_collect" class="hide">
        <div class="tip-box icon-box">
            <span class="warn-icon m-icon"></span>
            <div class="item-fore">
                <h3 class="ftx-04">移到收藏</h3>
                <div class="ftx-03">移动后选中商品将不在购物车中显示。</div>
            </div>
        </div>
    </div>

    <div id="flow_add_cart" class="hide">
        <div class="tip-box icon-box">
            <span class="warn-icon m-icon"></span>
            <div class="item-fore">
                <h3 class="ftx-04">请至少选中一件商品！</h3>
            </div>
        </div>
    </div>

    <div id="cart_gift_goods" class="hide">
        <div class="tip-box icon-box">
            <span class="warn-icon m-icon"></span>
            <div class="item-fore">
                <h3 class="ftx-04 rem">最多领取<em ectype="giftNumber"></em>个商品</h3>
            </div>
        </div>
    </div>




    <div id="set_default" class="hide">
        <div class="tip-box icon-box">
            <span class="warn-icon m-icon"></span>
            <div class="item-fore">
                <h3 class="ftx-04">您确定要设置为默认收货地址吗？</h3>
            </div>
        </div>
    </div>

    <div id="del_address" class="hide">
        <div class="tip-box icon-box">
            <span class="warn-icon m-icon"></span>
            <div class="item-fore">
                <h3 class="ftx-04">你确认要删除该收货地址吗？</h3>
            </div>
        </div>
    </div>

    <div id="no_address_cart" class="hide">
        <div class="tip-box icon-box">
            <span class="warn-icon m-icon"></span>
            <div class="item-fore">
                <h3 class="ftx-04">您还没有选择收货地址！</h3>
            </div>
        </div>
    </div>

    <div id="no_goods_cart" class="hide">
        <div class="tip-box icon-box">
            <span class="warn-icon m-icon"></span>
            <div class="item-fore">
                <h3 class="ftx-04">您的购物车中没有商品！</h3>
            </div>
        </div>
    </div>

    <div id="cart_address_not" class="hide">
        <div class="tip-box icon-box">
            <span class="warn-icon m-icon"></span>
            <div class="item-fore">
                <h3 class="ftx-04">您还没有选择收货地址！</h3>
            </div>
        </div>
    </div>


</div>
<div class="footer-new">
    <div class="footer-new-top">
        <div class="w w1200">
            <div class="service-list">
                <div class="service-item">
                    <i class="f-icon f-icon-qi"></i>
                    <span>七天包退</span>
                </div>
                <div class="service-item">
                    <i class="f-icon f-icon-zheng"></i>
                    <span>正品保障</span>
                </div>
                <div class="service-item">
                    <i class="f-icon f-icon-hao"></i>
                    <span>好评如潮</span>
                </div>
                <div class="service-item">
                    <i class="f-icon f-icon-shan"></i>
                    <span>闪电发货</span>
                </div>
                <div class="service-item">
                    <i class="f-icon f-icon-quan"></i>
                    <span>权威荣誉</span>
                </div>
            </div>
            <div class="contact">
                <div class="contact-item contact-item-first"><i class="f-icon f-icon-tel"></i><span>4000-000-000</span>
                </div>
                <div class="contact-item">
                    <a id="IM" im_type="dsc" onclick="openWin(this)" href="javascript:;" class="btn-ctn"><i
                            class="f-icon f-icon-kefu"></i><span>咨询客服</span></a>
                </div>
            </div>
        </div>
    </div>
    <div class="footer-new-con">
        <div class="fnc-warp">
            <div class="help-list">
                <?php if(is_array($helpCateRes) || $helpCateRes instanceof \think\Collection || $helpCateRes instanceof \think\Paginator): $i = 0; $__LIST__ = $helpCateRes;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$list): $mod = ($i % 2 );++$i;?>
                <div class="help-item">
                    <h3><?php echo $list['cate_name']; ?></h3>
                    <ul>
                        <?php if(is_array($list['arts']) || $list['arts'] instanceof \think\Collection || $list['arts'] instanceof \think\Paginator): $i = 0; $__LIST__ = $list['arts'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$list2): $mod = ($i % 2 );++$i;?>
                        <li><a href="<?php echo url('Article/index',array('artID'=>$list2['id'])); ?>"><?php echo $list2['title']; ?></a></li>
                        <?php endforeach; endif; else: echo "" ;endif; ?>
                    </ul>
                </div>
                <?php endforeach; endif; else: echo "" ;endif; ?>
            </div>
            <div class="qr-code">
                <div class="qr-item qr-item-first">
                    <div class="code_img"><img src="__INDEX__/img/ecjia_qrcode.png"></div>
                    <div class="code_txt">官方网址</div>
                </div>
                <div class="qr-item">
                    <div class="code_img"><img src="__INDEX__/img/ectouch_qrcode.png"></div>
                    <div class="code_txt">在线课程</div>
                </div>
            </div>
        </div>
    </div>
    <div class="footer-new-bot">
        <div class="w w1200">

            <p class="copyright_links">
                <a href="/">首页</a>
                <?php if(is_array($shopHelpArts) || $shopHelpArts instanceof \think\Collection || $shopHelpArts instanceof \think\Paginator): $i = 0; $__LIST__ = $shopHelpArts;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$list): $mod = ($i % 2 );++$i;?>
                <span class="spacer"></span>
                <a href="<?php echo url('Article/index',array('artID'=>$list['id'])); ?>"><?php echo $list['title']; ?></a>
                <?php endforeach; endif; else: echo "" ;endif; ?>
            </p>

            <p><span>©&nbsp;2015-2017&nbsp;tongpankt.com&nbsp;版权所有&nbsp;&nbsp;</span><span>ICP备案证书号:</span><a href="#">豫ICP备*****号-1</a>&nbsp;<a
                    href="#">POWERED by童攀课堂</a></p>

            <p class="copyright_auth">&nbsp;</p>
        </div>
    </div>


    <div class="hide" id="pd_coupons">
        <span class="success-icon m-icon"></span>
        <div class="item-fore">
            <h3>领取成功！感谢您的参与，祝您购物愉快~</h3>
            <div class="txt ftx-03">本活动为概率性事件，不能保证所有客户成功领取优惠券</div>
        </div>
    </div>


    <div class="hidden">
        <input name="seller_kf_IM" value="" rev="" ru_id="" type="hidden">
        <input name="seller_kf_qq" value="349488953" type="hidden">
        <input name="seller_kf_tel" value="4000-000-000" type="hidden">
        <input name="user_id" value="62" type="hidden">
    </div>
</div>
<script>
    // 2. 检查登录
    var check_log = "<?php echo url("member/Account/checkLogin"); ?>";
    // 3. 退出登录
    var login_out = "<?php echo url('member/Account/logoutA'); ?>";
    // 4. 去往登录页面
    var login_go = "<?php echo url('member/Account/login'); ?>";
    // 5. 去往注册页面
    var register_go = "<?php echo url('member/Account/reg'); ?>";

</script>
<script src="__INDEX__/js/check-log.js"></script>

<script type="text/javascript" src="__INDEX__/js/suggest.js"></script><script type="text/javascript" src="__INDEX__/js/scroll_city.js"></script><script type="text/javascript" src="__INDEX__/js/utils.js"></script>
<script type="text/javascript" src="__INDEX__/js/warehouse.js"></script><script type="text/javascript" src="__INDEX__/js/warehouse_area.js"></script>
<script type="text/javascript" src="__INDEX__/js/jquery.SuperSlide.2.1.1.js"></script><script type="text/javascript" src="__INDEX__/js/common.js"></script><script type="text/javascript" src="__INDEX__/js/shopping_flow.js"></script><script type="text/javascript" src="__INDEX__/js/jquery.nyroModal.js"></script><script type="text/javascript" src="__INDEX__/js/perfect-scrollbar/perfect-scrollbar.min.js"></script><script type="text/javascript" src="__INDEX__/js/lib_ecmobanFunc.js"></script><script type="text/javascript" src="__INDEX__/js/jquery.validation.min.js"></script>
<script type="text/javascript" src="__INDEX__/js/dsc-common.js"></script>
<script type="text/javascript" src="__INDEX__/js/jquery.purebox.js"></script>
<script type="text/javascript" src="__INDEX__/js/region.js"></script>

<script type="text/javascript">
    $(function(){
        $(".p-mode-list .p-mode-item").click(function(){
            var onlinepay_type = $(this).attr('flag');
            var order_sn = $(this).attr('order_sn');
            $.ajax({
                async: false,
                url:"flow.php?act=onlinepay_edit&onlinepay_type="+onlinepay_type+"&order_sn="+order_sn,
            });
        });


        $(".p-mode-item input").click(function(){
            var content = $("#pay_Dialog").html();
            pb({
                id:"payDialog",
                title:json_languages.payTitle,
                width:550,
                height:300,
                content:content,
                drag:false,
                foot:false
            });
        });

        //微信支付定时查询订单状态 by wanglu
        checkOrder();

        //微信扫码
        $("[data-type='wxpay']").on("click",function(){
            var content = $("#wxpay_dialog").html();
            pb({
                id: "scanCode",
                title: "",
                width: 716,
                content: content,
                drag: true,
                foot: false,
                cl_cBtn: false,
                cBtn: false
            });
        });
    });

    var timer;
    function checkOrder(){
        var pay_name = "在线支付";
        var pay_status = "0";
        var url = "flow.php?step=checkorder&order_id=17";
        if(pay_name == json_languages.payment_is_online && pay_status == 0){
            $.get(url, {}, function(data){
                //已付款
                if(data.code > 0 && data.pay_code == 'wxpay'){
                    clearTimeout(timer);
                    location.href = "respond.php?code=" + data.pay_code + "&status=1";
                }
            },'json');
        }
        timer = setTimeout("checkOrder()", 5000);
    }
</script>

<script type="text/javascript">
    $(function(){
        $("input[name='store_order']").val(0);

        $(document).on('click', "[ectype='store_order']", function(){
            var i = 0;
            $("*[ectype='ckShopAll']").each(function(){
                var t = $(this);
                if(t.prop("checked") == true){
                    i++
                }
            });

            if(i > 1){
                pbDialog(json_languages.not_seller_batch_goods_num,"",0,'','',55);
            }else{
                $("input[name='store_order']").val(1);
                $("form[name='formCart']").submit();
            }
        });
    })
</script>
</body>
</html>