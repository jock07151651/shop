<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:73:"D:\phpstudy_pro\WWW\shop\public/../application/index\view\flow\flow1.html";i:1597906096;s:76:"D:\phpstudy_pro\WWW\shop\public/../application/index\view\common\footer.html";i:1597926837;}*/ ?>

<!doctype html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="Keywords" content="童攀课堂-php课堂-www.tongpankt.com" />
    <meta name="Description" content="童攀课堂-php课堂-www.tongpankt.com" />
    <title>交流群：383432579</title>
    <link rel="shortcut icon" href="favicon.ico" />
    <link rel="stylesheet" type="text/css" href="__INDEX__/css/base.css" />
    <link rel="stylesheet" type="text/css" href="__INDEX__/css/style.css" />
    <link rel="stylesheet" type="text/css" href="__INDEX__/css/iconfont.css" />
    <link rel="stylesheet" type="text/css" href="__INDEX__/css/purebox.css" />
    <link rel="stylesheet" type="text/css" href="__INDEX__/css/quickLinks.css" />

    <script type="text/javascript" src="__INDEX__/js/jquery-1.9.1.min.js"></script><script type="text/javascript" src="__INDEX__/js/jquery.json.js"></script><script type="text/javascript" src="__INDEX__/js/transport_jquery.js"></script>
    <script type="text/javascript">
        // 获取商品数量，金额
        var ajax_cart_goods_amount = "<?php echo url('index/Flow/AjaxCartGoodsAmount'); ?>";
        // 批量删除商品跳转页面
        var ajax_delete_cart_goods = "<?php echo url('index/Flow/flow1'); ?>";
        // 更新头部购物车数量.防止订单表全选出错误
        var cart_goods_num = "<?php echo url('index/Flow/cartGoodsNum'); ?>";
        // 支付跳转登录
        var login_dailog = "<?php echo url('index/Flow/loginDailog'); ?>";

        var json_languages = {"ok":"\u786e\u5b9a","determine":"\u786e\u5b9a","cancel":"\u53d6\u6d88","drop":"\u5220\u9664","edit":"\u7f16\u8f91","remove":"\u79fb\u9664","follow":"\u5173\u6ce8","pb_title":"\u63d0\u793a","Prompt_information":"\u63d0\u793a\u4fe1\u606f","title":"\u63d0\u793a","not_login":"\u60a8\u5c1a\u672a\u767b\u5f55","close":"\u5173\u95ed","cart":"\u8d2d\u7269\u8f66","js_cart":"\u8d2d\u7269\u8f66","all":"\u5168\u90e8","go_login":"\u53bb\u767b\u9646","select_city":"\u8bf7\u9009\u62e9\u5e02","comment_goods":"\u8bc4\u8bba\u5546\u54c1","submit_order":"\u63d0\u4ea4\u8ba2\u5355","sys_msg":"\u7cfb\u7edf\u63d0\u793a","no_keywords":"\u8bf7\u8f93\u5165\u641c\u7d22\u5173\u952e\u8bcd\uff01","adv_packup_one":"\u8bf7\u53bb\u540e\u53f0\u5e7f\u544a\u4f4d\u7f6e","adv_packup_two":"\u91cc\u9762\u8bbe\u7f6e\u5e7f\u544a\uff01","more":"\u66f4\u591a","Please":"\u8bf7\u53bb","set_up":"\u8bbe\u7f6e\uff01","login_phone_packup_one":"\u8bf7\u8f93\u5165\u624b\u673a\u53f7\u7801","more_options":"\u66f4\u591a\u9009\u9879","Pack_up":"\u6536\u8d77","no_attr":"\u6ca1\u6709\u66f4\u591a\u5c5e\u6027\u4e86","search_Prompt":"\u53ef\u8f93\u5165\u6c49\u5b57,\u62fc\u97f3\u67e5\u627e\u54c1\u724c","most_input":"\u6700\u591a\u53ea\u80fd\u9009\u62e95\u9879","multi_select":"\u591a\u9009","checkbox_Packup":"\u8bf7\u6536\u8d77\u5168\u90e8\u591a\u9009","radio_Packup":"\u8bf7\u6536\u8d77\u5168\u90e8\u5355\u9009","contrast":"\u5bf9\u6bd4","empty_contrast":"\u6e05\u7a7a\u5bf9\u6bd4\u680f","Prompt_add_one":"\u6700\u591a\u53ea\u80fd\u6dfb\u52a04\u4e2a\u54e6^_^","Prompt_add_two":"\u60a8\u8fd8\u53ef\u4ee5\u7ee7\u7eed\u6dfb\u52a0","button_compare":"\u6bd4\u8f83\u9009\u5b9a\u5546\u54c1","exist":"\u60a8\u5df2\u7ecf\u9009\u62e9\u4e86%s","count_limit":"\u6700\u591a\u53ea\u80fd\u9009\u62e94\u4e2a\u5546\u54c1\u8fdb\u884c\u5bf9\u6bd4","goods_type_different":"%s\u548c\u5df2\u9009\u62e9\u5546\u54c1\u7c7b\u578b\u4e0d\u540c\u65e0\u6cd5\u8fdb\u884c\u5bf9\u6bd4","compare_no_goods":"\u60a8\u6ca1\u6709\u9009\u5b9a\u4efb\u4f55\u9700\u8981\u6bd4\u8f83\u7684\u5546\u54c1\u6216\u8005\u6bd4\u8f83\u7684\u5546\u54c1\u6570\u5c11\u4e8e 2 \u4e2a\u3002","btn_buy":"\u8d2d\u4e70","is_cancel":"\u53d6\u6d88","select_spe":"\u8bf7\u9009\u62e9\u5546\u54c1\u5c5e\u6027","Province":"\u8bf7\u9009\u62e9\u6240\u5728\u7701\u4efd","City":"\u8bf7\u9009\u62e9\u6240\u5728\u5e02","District":"\u8bf7\u9009\u62e9\u6240\u5728\u533a\u57df","Street":"\u8bf7\u9009\u62e9\u6240\u5728\u8857\u9053","Detailed_address_null":"\u8be6\u7ec6\u5730\u5740\u4e0d\u80fd\u4e3a\u7a7a","Select_attr":"\u8bf7\u9009\u62e9\u5c5e\u6027","Focus_prompt_one":"\u60a8\u5df2\u5173\u6ce8\u8be5\u5e97\u94fa\uff01","Focus_prompt_login":"\u60a8\u5c1a\u672a\u767b\u5f55\u5546\u57ce\u4f1a\u5458\uff0c\u4e0d\u80fd\u5173\u6ce8\uff01","Focus_prompt_two":"\u767b\u5f55\u5546\u57ce\u4f1a\u5458\u3002","store_focus":"\u5e97\u94fa\u5173\u6ce8\u3002","Focus_prompt_three":"\u60a8\u786e\u5b9e\u8981\u5173\u6ce8\u6240\u9009\u5e97\u94fa\u5417\uff1f","Focus_prompt_four":"\u60a8\u786e\u5b9e\u8981\u53d6\u6d88\u5173\u6ce8\u5e97\u94fa\u5417\uff1f","Focus_prompt_five":"\u60a8\u8981\u5173\u6ce8\u8be5\u5e97\u94fa\u5417\uff1f","Purchase_quantity":"\u8d85\u8fc7\u9650\u8d2d\u6570\u91cf.","My_collection":"\u6211\u7684\u6536\u85cf","shiping_prompt":"\u8be5\u5730\u533a\u6682\u4e0d\u652f\u6301\u914d\u9001","Have_goods":"\u6709\u8d27","No_goods":"\u5f88\u62b1\u6b49\uff0c\u65e0\u8d27\u5566","No_shipping":"\u5f88\u62b1\u6b49\uff0c\u65e0\u6cd5\u914d\u9001","Deliver_back_order":"\u4e0b\u5355\u540e\u7acb\u5373\u53d1\u8d27","Time_delivery":" \u65f6\u53d1\u8d27","goods_over":"\u6b64\u5546\u54c1\u6682\u65f6\u552e\u5b8c","Stock_goods_null":"\u5546\u54c1\u5e93\u5b58\u4e0d\u8db3","purchasing_prompt_two":"\u5bf9\u4e0d\u8d77\uff0c\u8be5\u5546\u54c1\u5df2\u7ecf\u7d2f\u8ba1\u8d85\u8fc7\u9650\u8d2d\u6570\u91cf","day_not_available":"\u5f53\u65e5\u65e0\u8d27","day_yes_available":"\u5f53\u65e5\u6709\u8d27","Already_buy":"\u5df2\u8d2d\u4e70","Already_buy_two":"\u4ef6\u5546\u54c1\u8fbe\u5230\u9650\u8d2d\u6761\u4ef6,\u65e0\u6cd5\u518d\u8d2d\u4e70","Already_buy_three":"\u4ef6\u8be5\u5546\u54c1,\u53ea\u80fd\u518d\u8d2d\u4e70","goods_buy_empty_p":"\u5546\u54c1\u6570\u91cf\u4e0d\u80fd\u5c11\u4e8e1\u4ef6","goods_number_p":"\u5546\u54c1\u6570\u91cf\u5fc5\u987b\u4e3a\u6570\u5b57","search_one":"\u8bf7\u586b\u5199\u7b5b\u9009\u4ef7\u683c","search_two":"\u8bf7\u586b\u5199\u7b5b\u9009\u5de6\u8fb9\u4ef7\u683c","search_three":"\u8bf7\u586b\u5199\u7b5b\u9009\u53f3\u8fb9\u4ef7\u683c","search_four":"\u5de6\u8fb9\u4ef7\u683c\u4e0d\u80fd\u5927\u4e8e\u6216\u7b49\u4e8e\u53f3\u8fb9\u4ef7\u683c","jian":"\u4ef6","letter":"\u4ef6","inventory":"\u5b58\u8d27","move_collection":"\u79fb\u81f3\u6211\u7684\u6536\u85cf","select_shop":"\u8bf7\u9009\u62e9\u5957\u9910\u5546\u54c1","Parameter_error":"\u53c2\u6570\u9519\u8bef","screen_price":"\u8bf7\u586b\u5199\u7b5b\u9009\u4ef7\u683c","screen_price_left":"\u8bf7\u586b\u5199\u7b5b\u9009\u5de6\u8fb9\u4ef7\u683c","screen_price_right":"\u8bf7\u586b\u5199\u7b5b\u9009\u53f3\u8fb9\u4ef7\u683c","screen_price_dy":"\u5de6\u8fb9\u4ef7\u683c\u4e0d\u80fd\u5927\u4e8e\u6216\u7b49\u4e8e\u53f3\u8fb9\u4ef7\u683c","invoice_ok":"\u4fdd\u5b58\u53d1\u7968\u4fe1\u606f","invoice_desc_null":"\u8f93\u5165\u5185\u5bb9\u4e0d\u80fd\u4e3a\u7a7a\uff01","invoice_desc_number":"\u60a8\u6700\u591a\u53ef\u4ee5\u6dfb\u52a03\u4e2a\u516c\u53f8\u53d1\u7968\uff01","invoice_packup":"\u8bf7\u9009\u62e9\u6216\u586b\u5199\u53d1\u7968\u62ac\u5934\u90e8\u5206\uff01","invoice_tax_null":"\u8bf7\u586b\u5199\u7eb3\u7a0e\u4eba\u8bc6\u522b\u7801","add_address_10":"\u6700\u591a\u53ea\u80fd\u6dfb\u52a010\u4e2a\u6536\u8d27\u5730\u5740","msg_phone_not":"\u624b\u673a\u53f7\u7801\u4e0d\u6b63\u786e","captcha_not":"\u9a8c\u8bc1\u7801\u4e0d\u80fd\u4e3a\u7a7a","captcha_xz":"\u8bf7\u8f93\u51654\u4f4d\u6570\u7684\u9a8c\u8bc1\u7801","captcha_cw":"\u9a8c\u8bc1\u7801\u9519\u8bef","Detailed_map":"\u8be6\u7ec6\u5730\u56fe","email_error":"\u90ae\u7bb1\u683c\u5f0f\u4e0d\u6b63\u786e\uff01","bid_prompt_null":"\u4ef7\u683c\u4e0d\u80fd\u4e3a\u7a7a!","bid_prompt_error":"\u4ef7\u683c\u8f93\u5165\u683c\u5f0f\u4e0d\u6b63\u786e\uff01","mobile_error_goods":"\u624b\u673a\u683c\u5f0f\u4e0d\u6b63\u786e\uff01","null_email_goods":"\u90ae\u7bb1\u4e0d\u80fd\u4e3a\u7a7a","select_store":"\u8bf7\u9009\u62e9\u95e8\u5e97\uff01","Product_spec_prompt":"\u8bf7\u9009\u62e9\u5546\u54c1\u89c4\u683c\u7c7b\u578b","reply_desc_one":"\u56de\u590d\u5e16\u5b50\u5185\u5bb9\u4e0d\u80fd\u4e3a\u7a7a","go_shoping":"\u53bb\u8d2d\u7269","highest_price":"\u5df2\u662f\u6700\u9ad8\u4ef7\uff01","lowest_price":"\u5df2\u662f\u6700\u4f4e\u4ef7\uff01","no_history":"\u60a8\u5df2\u6e05\u7a7a\u6700\u8fd1\u6d4f\u89c8\u8fc7\u7684\u5546\u54c1","receive_coupons":"\u9886\u53d6\u4f18\u60e0\u5238","Immediate_use":"\u7acb\u5373\u4f7f\u7528","no_enabled":"\u5173\u95ed","Purchase_restrictions":"\u8d2d\u4e70\u6570\u91cf\u4e0d\u80fd\u5c11\u4e8e1\u4ef6","remove_checked_goods":"\u5220\u9664\u9009\u4e2d\u7684\u5546\u54c1","go_up":"\u7ee7\u7eed","back_cart":"\u8fd4\u56de\u8d2d\u7269\u8f66","save":"\u4fdd\u5b58","delivery_Prompt":"\u8be5\u533a\u57df\u6ca1\u6709\u63d0\u8d27\u70b9!","delivery_Prompt_two":"\u8bf7\u9009\u62e9\u63d0\u8d27\u65f6\u95f4\u6bb5!","checked_address":"\u8bf7\u9009\u62e9\u6536\u8d27\u5730\u5740!","no_store":"\u8be5\u5730\u533a\u6ca1\u6709\u95e8\u5e97!","buy_more":"\u6700\u591a\u9886\u53d6","a_goods":"\u4e2a\u5546\u54c1","drop_goods":"\u5220\u9664\u5546\u54c1\uff1f","drop_desc":"\u60a8\u53ef\u4ee5\u9009\u62e9\u79fb\u5230\u6536\u85cf\uff0c\u6216\u5220\u9664\u5546\u54c1\u3002","Move_collection":"\u79fb\u5230\u6536\u85cf","Move_desc":"\u79fb\u52a8\u540e\u9009\u4e2d\u5546\u54c1\u5c06\u4e0d\u5728\u8d2d\u7269\u8f66\u4e2d\u663e\u793a\u3002","confirm_default_address":"\u60a8\u786e\u5b9a\u8981\u8bbe\u7f6e\u4e3a\u9ed8\u8ba4\u6536\u8d27\u5730\u5740\u5417\uff1f","confirm_drop_address":"\u60a8\u786e\u5b9a\u8981\u5220\u9664\u8be5\u6536\u8d27\u5730\u5740\u5417\uff1f","please_checked_address":"\u60a8\u8fd8\u6ca1\u6709\u9009\u62e9\u6536\u8d27\u5730\u5740\uff01","cart_empty_goods":"\u60a8\u7684\u8d2d\u7269\u8f66\u4e2d\u6ca1\u6709\u5546\u54c1\uff01","confirm_Move_collection":"\u79fb\u52a8\u540e\u9009\u4e2d\u5546\u54c1\u5c06\u4e0d\u5728\u8d2d\u7269\u8f66\u4e2d\u663e\u793a\uff01","Shipping_address":"\u6536\u8d27\u5730\u5740","add_shipping_address":"\u6dfb\u52a0\u6536\u8d27\u5730\u5740","no_delivery":"\u6682\u4e0d\u652f\u6301\u8be5\u5730\u533a\u914d\u9001\u3002","delivery_information":"\u914d\u9001\u4fe1\u606f","pay_password_packup_null":"\u652f\u4ed8\u5bc6\u7801\u4e0d\u80fd\u4e3a\u7a7a\uff01","pay_password_packup_error":"\u60a8\u7684\u652f\u4ed8\u5bc6\u7801\u6709\u8bef\uff01","flow_no_payment":"\u60a8\u5fc5\u987b\u9009\u5b9a\u4e00\u4e2a\u652f\u4ed8\u65b9\u5f0f","flow_no_shipping":"\u60a8\u5fc5\u987b\u9009\u5b9a\u4e00\u4e2a\u914d\u9001\u65b9\u5f0f","Mobile_error":"\u624b\u673a\u53f7\u683c\u5f0f\u4e0d\u6b63\u786e\uff01","phone_error":"\u7535\u8bdd\u53f7\u7801\u683c\u5f0f\u4e0d\u6b63\u786e\uff01","order_detail":"\u8ba2\u5355\u8be6\u60c5","down_detail":"\u6536\u8d77\u8be6\u60c5","payTitle":"\u6b63\u5728\u652f\u4ed8","select_consigne":"\u8bf7\u9009\u62e9\u6240\u5728\u56fd\u5bb6","consignee_legitimate_email":"\u60a8\u8f93\u5165\u7684\u90ae\u4ef6\u5730\u5740\u4e0d\u662f\u4e00\u4e2a\u5408\u6cd5\u7684\u90ae\u4ef6\u5730\u5740","consignee_legitimate_phone":"\u624b\u673a\u53f7\u7801\u4e0d\u5408\u6cd5","input_Consignee_name":"\u8bf7\u60a8\u586b\u5199\u6536\u8d27\u4eba\u59d3\u540d","con_Preservation":"\u4fdd\u5b58\u6536\u8d27\u4eba\u4fe1\u606f","Preservation":"\u4fdd\u5b58","add_invoice":"\u65b0\u589e\u5355\u4f4d\u53d1\u7968"};
        //加载效果
        var load_cart_info = '<img src="__INDEX__/img/loadGoods.gif" height="108" class="ml100">';
        var load_icon = '<img src="__INDEX__/img/load.gif" width="200" height="200">';
    </script><link rel="stylesheet" type="text/css" href="__INDEX__/css/perfect-scrollbar.min.css" />
</head>

<body class="bg-ligtGary">
<div class="site-nav" id="site-nav">
    <div class="w w1200">
        <div class="fl">
            <div class="txt-info" id="ECS_MEMBERZONE">
                <div class='scrollBody' id='scrollBody'></div>
            </div>
        </div>
        <ul class="quick-menu fr">
            <li>
                <div class="dt"><a href="#" >我的订单</a></div>
            </li>
            <li class="spacer"></li>
            <li>
                <div class="dt"><a href="#" >我的浏览</a></div>
            </li>
            <li class="spacer"></li>
            <li>
                <div class="dt"><a href="#" >我的收藏</a></div>
            </li>
            <li class="spacer"></li>
            <li>
                <div class="dt"><a href="#" >客户服务</a></div>
            </li>
            <li class="spacer"></li>
            <li class="li_dorpdown" data-ectype="dorpdown">
                <div class="dt dsc-cm">网站导航<i class="iconfont icon-down"></i></div>
                <div class="dd dorpdown-layer">
                    <dl class="fore1">
                        <dt>特色主题</dt>
                        <dd>
                            <div class="item"><a href="#" target="_blank">家用电器</a></div>
                            <div class="item"><a href="#" target="_blank">手机数码</a></div>
                            <div class="item"><a href="#" target="_blank">电脑办公</a></div>
                        </dd>
                    </dl>
                    <dl class="fore2">
                        <dt>促销活动</dt>
                        <dd>
                            <div class="item"><a href="#">拍卖活动</a></div>
                            <div class="item"><a href="#">共创商品</a></div>
                            <div class="item"><a href="#">优惠活动</a></div>
                            <div class="item"><a href="#">批发市场</a></div>
                            <div class="item"><a href="#">超值礼包</a></div>
                            <div class="item"><a href="#">优惠券</a></div>
                        </dd>
                    </dl>
                </div>
            </li>
        </ul>
    </div>
</div>
<div class="header header-cart">
    <div class="w w1200">
        <div class="logo">
            <div class="logoImg"><a href="/"><img src="__INDEX__/img/logo.png" /></a></div>
            <div class="tit">购物车（<em ectype="cartNum">2</em>）</div>
        </div>
        <div class="dsc-search">
            <div class="form">
                <form id="searchForm" name="searchForm" method="get" action="search.php" onSubmit="return checkSearchForm()" class="search-form">
                    <input autocomplete="off" onKeyUp="lookup(this.value);" name="keywords" type="text" id="keyword" value="内衣" class="search-text"/>
                    <input type="hidden" name="store_search_cmt" value="0">
                    <button type="submit" class="button button-icon"><i></i></button>
                </form>

                <div class="suggestions_box" id="suggestions" style="display:none;">
                    <div class="suggestions_list" id="auto_suggestions_list">
                        &nbsp;
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>        <div class="container">
    <div class="w w1200">

        <div class="cart-warp">
            <div class="cart-filter">
                <div class="cart-stepflex">
                    <div class="cart-step-item curr">
                        <span>1.我的购物车</span>
                        <i class="iconfont icon-arrow-right-alt"></i>
                    </div>
                    <div class="cart-step-item">
                        <span>2.填写订单信息</span>
                        <i class="iconfont icon-arrow-right-alt"></i>
                    </div>
                    <div class="cart-step-item">
                        <span>3.成功提交订单</span>
                    </div>
                </div>
                <div class="sp-area store-selector">
                    <div class="text-select" id="area_address" ectype="areaSelect">
                        <span class="txt">配送至</span>
                        <div class="selector">

                            <div class="tit">
                                <span>安徽&nbsp;蚌埠&nbsp;东市区</span><i class="iconfont icon-down"></i>
                            </div>
                            <div class="area-warp" id="area_list">
                                <ul class="tab" id="select_area">
                                    <li onclick="region.selectArea(this, 1);" value="3" id="province_li">安徽<i class="sc-icon-right"></i></li>
                                    <li onclick="region.selectArea(this, 2);" value="37" id="city_li">蚌埠<i class="sc-icon-right"></i></li>
                                    <li class="curr" onclick="region.selectArea(this, 3);" value="" id="district_type">东市区<i class="sc-icon-right"></i></li>
                                </ul>
                                <div class="tab-content" id="house_list" style="display:none;" >
                                    <ul id="province_list">

                                        <li>
                                            <a v="2" title="北京" onclick="region.getRegion(2, 2, city_list, this,0,);" href="javascript:void(0);">北京</a>
                                        </li>
                                        <li>
                                            <a v="3" title="安徽" onclick="region.getRegion(3, 2, city_list, this,0,);" href="javascript:void(0);">安徽</a>
                                        </li>
                                        <li>
                                            <a v="4" title="福建" onclick="region.getRegion(4, 2, city_list, this,0,);" href="javascript:void(0);">福建</a>
                                        </li>
                                        <li>
                                            <a v="5" title="甘肃" onclick="region.getRegion(5, 2, city_list, this,0,);" href="javascript:void(0);">甘肃</a>
                                        </li>
                                        <li>
                                            <a v="6" title="广东" onclick="region.getRegion(6, 2, city_list, this,0,);" href="javascript:void(0);">广东</a>
                                        </li>
                                        <li>
                                            <a v="7" title="广西" onclick="region.getRegion(7, 2, city_list, this,0,);" href="javascript:void(0);">广西</a>
                                        </li>
                                        <li>
                                            <a v="8" title="贵州" onclick="region.getRegion(8, 2, city_list, this,0,);" href="javascript:void(0);">贵州</a>
                                        </li>
                                        <li>
                                            <a v="9" title="海南" onclick="region.getRegion(9, 2, city_list, this,0,);" href="javascript:void(0);">海南</a>
                                        </li>
                                        <li>
                                            <a v="10" title="河北" onclick="region.getRegion(10, 2, city_list, this,0,);" href="javascript:void(0);">河北</a>
                                        </li>
                                        <li>
                                            <a v="11" title="河南" onclick="region.getRegion(11, 2, city_list, this,0,);" href="javascript:void(0);">河南</a>
                                        </li>
                                        <li>
                                            <a v="12" title="黑龙江" onclick="region.getRegion(12, 2, city_list, this,0,);" href="javascript:void(0);">黑龙江</a>
                                        </li>
                                        <li>
                                            <a v="13" title="湖北" onclick="region.getRegion(13, 2, city_list, this,0,);" href="javascript:void(0);">湖北</a>
                                        </li>
                                        <li>
                                            <a v="14" title="湖南" onclick="region.getRegion(14, 2, city_list, this,0,);" href="javascript:void(0);">湖南</a>
                                        </li>
                                        <li>
                                            <a v="15" title="吉林" onclick="region.getRegion(15, 2, city_list, this,0,);" href="javascript:void(0);">吉林</a>
                                        </li>
                                        <li>
                                            <a v="16" title="江苏" onclick="region.getRegion(16, 2, city_list, this,0,);" href="javascript:void(0);">江苏</a>
                                        </li>
                                        <li>
                                            <a v="17" title="江西" onclick="region.getRegion(17, 2, city_list, this,0,);" href="javascript:void(0);">江西</a>
                                        </li>
                                        <li>
                                            <a v="18" title="辽宁" onclick="region.getRegion(18, 2, city_list, this,0,);" href="javascript:void(0);">辽宁</a>
                                        </li>
                                        <li>
                                            <a v="19" title="内蒙古" onclick="region.getRegion(19, 2, city_list, this,0,);" href="javascript:void(0);">内蒙古</a>
                                        </li>
                                        <li>
                                            <a v="20" title="宁夏" onclick="region.getRegion(20, 2, city_list, this,0,);" href="javascript:void(0);">宁夏</a>
                                        </li>
                                        <li>
                                            <a v="21" title="青海" onclick="region.getRegion(21, 2, city_list, this,0,);" href="javascript:void(0);">青海</a>
                                        </li>
                                        <li>
                                            <a v="22" title="山东" onclick="region.getRegion(22, 2, city_list, this,0,);" href="javascript:void(0);">山东</a>
                                        </li>
                                        <li>
                                            <a v="23" title="山西" onclick="region.getRegion(23, 2, city_list, this,0,);" href="javascript:void(0);">山西</a>
                                        </li>
                                        <li>
                                            <a v="24" title="陕西" onclick="region.getRegion(24, 2, city_list, this,0,);" href="javascript:void(0);">陕西</a>
                                        </li>
                                        <li>
                                            <a v="25" title="上海" onclick="region.getRegion(25, 2, city_list, this,0,);" href="javascript:void(0);">上海</a>
                                        </li>
                                        <li>
                                            <a v="26" title="四川" onclick="region.getRegion(26, 2, city_list, this,0,);" href="javascript:void(0);">四川</a>
                                        </li>
                                        <li>
                                            <a v="27" title="天津" onclick="region.getRegion(27, 2, city_list, this,0,);" href="javascript:void(0);">天津</a>
                                        </li>
                                        <li>
                                            <a v="28" title="西藏" onclick="region.getRegion(28, 2, city_list, this,0,);" href="javascript:void(0);">西藏</a>
                                        </li>
                                        <li>
                                            <a v="29" title="新疆" onclick="region.getRegion(29, 2, city_list, this,0,);" href="javascript:void(0);">新疆</a>
                                        </li>
                                        <li>
                                            <a v="30" title="云南" onclick="region.getRegion(30, 2, city_list, this,0,);" href="javascript:void(0);">云南</a>
                                        </li>
                                        <li>
                                            <a v="31" title="浙江" onclick="region.getRegion(31, 2, city_list, this,0,);" href="javascript:void(0);">浙江</a>
                                        </li>
                                        <li>
                                            <a v="32" title="重庆" onclick="region.getRegion(32, 2, city_list, this,0,);" href="javascript:void(0);">重庆</a>
                                        </li>
                                        <li>
                                            <a v="33" title="香港" onclick="region.getRegion(33, 2, city_list, this,0,);" href="javascript:void(0);">香港</a>
                                        </li>
                                        <li>
                                            <a v="34" title="澳门" onclick="region.getRegion(34, 2, city_list, this,0,);" href="javascript:void(0);">澳门</a>
                                        </li>
                                        <li>
                                            <a v="35" title="台湾" onclick="region.getRegion(35, 2, city_list, this,0,);" href="javascript:void(0);">台湾</a>
                                        </li>

                                    </ul>
                                </div>
                                <div style="display: none;" class="tab-content" id="city_list_id">
                                    <ul id="city_list">


                                        <li>
                                            <a v="36" title="安庆" onclick="region.getRegion(36, 3, district_list, '安庆',0,);" href="javascript:void(0);">安庆</a>
                                        </li>

                                        <li>
                                            <a v="37" title="蚌埠" onclick="region.getRegion(37, 3, district_list, '蚌埠',0,);" href="javascript:void(0);">蚌埠</a>
                                        </li>

                                        <li>
                                            <a v="38" title="巢湖" onclick="region.getRegion(38, 3, district_list, '巢湖',0,);" href="javascript:void(0);">巢湖</a>
                                        </li>

                                        <li>
                                            <a v="39" title="池州" onclick="region.getRegion(39, 3, district_list, '池州',0,);" href="javascript:void(0);">池州</a>
                                        </li>

                                        <li>
                                            <a v="40" title="滁州" onclick="region.getRegion(40, 3, district_list, '滁州',0,);" href="javascript:void(0);">滁州</a>
                                        </li>

                                        <li>
                                            <a v="41" title="阜阳" onclick="region.getRegion(41, 3, district_list, '阜阳',0,);" href="javascript:void(0);">阜阳</a>
                                        </li>

                                        <li>
                                            <a v="42" title="淮北" onclick="region.getRegion(42, 3, district_list, '淮北',0,);" href="javascript:void(0);">淮北</a>
                                        </li>

                                        <li>
                                            <a v="43" title="淮南" onclick="region.getRegion(43, 3, district_list, '淮南',0,);" href="javascript:void(0);">淮南</a>
                                        </li>

                                        <li>
                                            <a v="44" title="黄山" onclick="region.getRegion(44, 3, district_list, '黄山',0,);" href="javascript:void(0);">黄山</a>
                                        </li>

                                        <li>
                                            <a v="45" title="六安" onclick="region.getRegion(45, 3, district_list, '六安',0,);" href="javascript:void(0);">六安</a>
                                        </li>

                                        <li>
                                            <a v="46" title="马鞍山" onclick="region.getRegion(46, 3, district_list, '马鞍山',0,);" href="javascript:void(0);">马鞍山</a>
                                        </li>

                                        <li>
                                            <a v="47" title="宿州" onclick="region.getRegion(47, 3, district_list, '宿州',0,);" href="javascript:void(0);">宿州</a>
                                        </li>

                                        <li>
                                            <a v="48" title="铜陵" onclick="region.getRegion(48, 3, district_list, '铜陵',0,);" href="javascript:void(0);">铜陵</a>
                                        </li>

                                        <li>
                                            <a v="49" title="芜湖" onclick="region.getRegion(49, 3, district_list, '芜湖',0,);" href="javascript:void(0);">芜湖</a>
                                        </li>

                                        <li>
                                            <a v="50" title="宣城" onclick="region.getRegion(50, 3, district_list, '宣城',0,);" href="javascript:void(0);">宣城</a>
                                        </li>

                                        <li>
                                            <a v="51" title="亳州" onclick="region.getRegion(51, 3, district_list, '亳州',0,);" href="javascript:void(0);">亳州</a>
                                        </li>

                                        <li>
                                            <a v="3401" title="合肥" onclick="region.getRegion(3401, 3, district_list, '合肥',0,);" href="javascript:void(0);">合肥</a>
                                        </li>


                                    </ul>
                                </div>
                                <div class="tab-content" id="district_list_id" style="display: block;">
                                    <ul id="district_list">

                                        <li>
                                            <a v="" title="中市区" onclick="region.changedDis(409,0);" href="javascript:void(0);" id="district_409">中市区</a>
                                        </li>
                                        <li>
                                            <a v="" title="东市区" onclick="region.changedDis(410,0);" href="javascript:void(0);" id="district_410">东市区</a>
                                        </li>
                                        <li>
                                            <a v="" title="西市区" onclick="region.changedDis(411,0);" href="javascript:void(0);" id="district_411">西市区</a>
                                        </li>
                                        <li>
                                            <a v="" title="郊区" onclick="region.changedDis(412,0);" href="javascript:void(0);" id="district_412">郊区</a>
                                        </li>
                                        <li>
                                            <a v="" title="怀远县" onclick="region.changedDis(413,0);" href="javascript:void(0);" id="district_413">怀远县</a>
                                        </li>
                                        <li>
                                            <a v="" title="五河县" onclick="region.changedDis(414,0);" href="javascript:void(0);" id="district_414">五河县</a>
                                        </li>
                                        <li>
                                            <a v="" title="固镇县" onclick="region.changedDis(415,0);" href="javascript:void(0);" id="district_415">固镇县</a>
                                        </li>


                                    </ul>
                                </div>
                                <div class="mod_storage_state">商品暂时只支持配送至中国大陆地区</div>
                                <input type="hidden" value="3" id="province_id" name="province_region_id">
                                <input type="hidden" value="37" id="city_id" name="city_region_id">
                                <input type="hidden" value="410" id="district_id" name="district_region_id">
                                <input type="hidden" value="" id="merchantId" name="merchantId">
                            </div>
                            <input type="hidden" value="2" id="region_id" name="region_id">
                            <input type="hidden" value="" id="good_id" name="good_id">
                            <input type="hidden" value="0" id="user_id" name="user_id">
                            <input type="hidden" value="16" id="area_id" name="area_id">
                            <input type="hidden" value="3" id="province_id" name="province_region_id">
                        </div>
                    </div>
                </div>
            </div>
            <div class="cart-table">
                <div class="cart-head">
                    <div class="column c-checkbox">
                        <div class="cart-checkbox cart-all-checkbox" ectype="ckList">
                            <input type="checkbox" id="cart-selectall" class="ui-checkbox checkboxshopAll" ectype="ckAll" />
                            <label for="cart-selectall" class="ui-label-14">全选</label>
                        </div>
                    </div>
                    <div class="column c-goods">商品</div>
                    <div class="column c-props">属性</div>
                    <div class="column c-price">单价（元）</div>
                    <div class="column c-quantity">数量</div>
                    <div class="column c-sum">小计</div>
                    <div class="column c-action">操作</div>
                </div>
                <div class="cart-tbody" ectype="cartTboy">
                    <!-- 商品 -->
                    <div class="cart-item" ectype="shopItem">

                        <div class="item-list" ectype="itemList">
                            <!-- 循环 -->
                            <?php if(is_array($cartGoodsRes) || $cartGoodsRes instanceof \think\Collection || $cartGoodsRes instanceof \think\Paginator): $i = 0; $__LIST__ = $cartGoodsRes;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$list): $mod = ($i % 2 );++$i;?>
                            <div class="item-single">
                                <div class="item-item selected" ectype="item" id="product_775" data-goodsid="775">
                                    <div class="item-form">
                                        <div class="cell s-checkbox">
                                            <div class="cart-checkbox" ectype="ckList">
                                                <!-- 勾中框发送商品id -->
                                                <input type="checkbox" id="checkItem_<?php echo $list['goodsid_attrid']; ?>" value="<?php echo $list['goodsid_attrid']; ?>" name="checkItem" class="ui-checkbox" ectype="ckGoods">
                                                <label for="checkItem_<?php echo $list['goodsid_attrid']; ?>" class="ui-label-14">&nbsp;</label>
                                            </div>
                                        </div>
                                        <div class="cell s-goods">
                                            <div class="goods-item">
                                                <div class="p-img">
                                                    <a href="#" target="_blank"><img src="__UPLOADS__/<?php echo $list['mid_thumb']; ?>" width="70" height="70"></a>
                                                </div>
                                                <div class="item-msg">
                                                    <a href="<?php echo url('index/Goods/index',array('goodsID'=>$list['goods_id'])); ?>" target="_blank"><?php echo $list['goods_name']; ?></a>
                                                    <div class="gds-types">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="cell s-props">
                                            <?php echo $list['goods_attr_str']; ?>
                                        </div>
                                        <div class="cell s-price">
                                            <strong id="goods_price_8"><em>¥</em><?php echo $list['member_price']; ?></strong>
                                        </div>
                                        <div class="cell s-quantity">
                                            <div class="amount-warp">
                                                <input type="text" value="<?php echo $list['goods_num']; ?>" name="goods_number[<?php echo $list['goodsid_attrid']; ?>]" id="goods_number_<?php echo $list['goodsid_attrid']; ?>" onchange="change_goods_number('<?php echo $list['goodsid_attrid']; ?>', this.value, 2, 16)" class="text buy-num" ectype="number" defaultnumber="1">
                                                <div class="a-btn">
                                                    <a href="#" onclick="changenum('<?php echo $list['goodsid_attrid']; ?>', 1, 2, 16,17,this)" class="btn-add"><i class="iconfont icon-up"></i></a>
                                                    <a href="#" onclick="changenum('<?php echo $list['goodsid_attrid']; ?>', -1, 2, 16,17,this)" class="btn-reduce <?php if($list['goods_num'] <= 1): ?>btn-disabled <?php endif; ?>"><i class="iconfont icon-down"></i></a>
                                                </div>
                                            </div>
                                            <div class="tc ftx-03">有货</div>
                                        </div>
                                        <div class="cell s-sum">
                                            <strong id="goods_subtotal_8"><font id="_8_subtotal"><em>¥</em><?php echo $list['sub_total']; ?></font></strong>
                                            <div class="cuttip hide">
                                                <span class="tit">优惠</span>
                                                <span class="price" id="discount_amount_8"><em>¥</em>0.00</span>
                                            </div>
                                        </div>
                                        <div class="cell s-action">
                                            <a href="#" id="remove_8" ectype="cartOperation" data-value="{&quot;divId&quot;:&quot;cart_remove&quot;,&quot;url&quot;:&quot;<?php echo url('index/Flow/dropGoodsAttr',array('id'=>$list['goodsid_attrid'])); ?>&quot;,&quot;cancelUrl&quot;:&quot;flow.php?step=drop_to_collect&amp;id=8&quot;,&quot;recid&quot;:8,&quot;title&quot;:&quot;删除&quot;}" class="cart-remove">删除</a>
                                            <a href="#" id="store_8" ectype="cartOperation" data-value="{&quot;divId&quot;:&quot;cart_collect&quot;,&quot;url&quot;:&quot;flow.php?step=drop_to_collect&amp;id=8&quot;,&quot;recid&quot;:8,&quot;title&quot;:&quot;关注&quot;}" class="cart-store">收藏</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; endif; else: echo "" ;endif; ?>
                            <!-- 循环结束 -->
                        </div>
                    </div>

                    <!-- 商品结束 -->
                </div>
                <div class="cart-tfoot">
                    <div class="cart-toolbar">
                        <div class="w w1200">
                            <div class="cart-checkbox cart-all-checkbox" ectype="ckList">
                                <input type="checkbox" id="toggle-checkboxes-down" class="ui-checkbox checkboxshopAll" ectype="ckAll" />
                                <label for="toggle-checkboxes-down" class="ui-label-14">全选</label>
                            </div>
                            <div class="operation">
                                <a href="#" class="cart-remove-batch" data-dialog="remove_collect_dialog" data-divid="cart-remove-batch" data-removeurl="<?php echo url('index/Flow/deleteCarts'); ?>" data-collecturl="ajax_dialog.php?act=drop_to_collect" data-title="删除">删除选中的商品</a>
                                <a href="#" class="cart-follow-batch" data-dialog="remove_collect_dialog" data-divid="cart-collect-batch" data-removeurl="ajax_dialog.php?act=delete_cart_goods" data-collecturl="ajax_dialog.php?act=drop_to_collect" data-title="关注">移到我的收藏</a>
                            </div>
                            <div class="toolbar-right">
                                <div class="comm-right">
                                    <div class="btn-area">
                                        <form name="formCart" method="post" action="<?php echo url('index/Flow/flow2'); ?>" onsubmit="return get_toCart();">
                                            <input name="goPay" type="submit" class="submit-btn" value="去支付"  <?php if(\think\Session::get('username') == ''): ?> id="go_pay"<?php endif; ?> data-url="flow.php"/>
                                            <input name="step" value="checkout" type="hidden" />
                                            <input name="store_seller" value="" type="hidden" id="cart_store_seller" />
                                            <input name="cart_value" id="cart_value" value="" type="hidden" />
                                            <input name="goods_ru" id="goods_ru" value="" type="hidden" />
                                        </form>
                                    </div>
                                    <div class="price-sum" id="total_desc">
                                        <span class="txt">总价(不含运费)：</span>
                                        <span class="price sumPrice" id="cart_goods_amount" ectype="goods_total"></span>
                                    </div>
                                    <div class="reduce-sum">
                                        <span class="txt">已节省：</span>
                                        <span class="price totalRePrice" id="save_total_amount" ectype="save_total"></span>
                                    </div>
                                    <div class="amount-sum">已选择<em class="cart_check_num" ectype="cartNum">0</em>件商品</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="p-panel-main c-history">
            <div class="ftit ftit-delr"><h3>猜你喜欢</h3></div>
            <div class="gl-list clearfix">
                <ul class="clearfix">
                    <li class="opacity_img">
                        <div class="p-img"><a href="#" target="_blank"><img src="__INDEX__/img/0_thumb_G_1489109583798.jpg" width="190" height="190"></a></div>
                        <div class="p-price"><em>¥</em>555.00</div>
                        <div class="p-name"><a href="#" target="_blank">【情侣款】Camel骆驼男靴 时尚潮流英伦风马丁靴高帮皮靴 爆卖1万双！ 情侣马丁靴 好评如潮</a></div>
                        <div class="p-num">已售<em>35</em>件</div>
                    </li>
                    <li class="opacity_img">
                        <div class="p-img"><a href="#" target="_blank"><img src="__INDEX__/img/0_thumb_G_1489109633806.jpg" width="190" height="190"></a></div>
                        <div class="p-price"><em>¥</em>1000.00</div>
                        <div class="p-name"><a href="#" target="_blank">春季马丁靴男真皮男靴黄靴工装军靴韩版短靴沙漠靴高帮男鞋大黄靴 头层牛皮</a></div>
                        <div class="p-num">已售<em>2</em>件</div>
                    </li>
                    <li class="opacity_img">
                        <div class="p-img"><a href="#" target="_blank"><img src="__INDEX__/img/0_thumb_G_1489108999364.jpg" width="190" height="190"></a></div>
                        <div class="p-price"><em>¥</em>200.00</div>
                        <div class="p-name"><a href="#" target="_blank">特步女鞋2017春季新款运动鞋休闲鞋女慢跑步鞋旅游鞋轻便舒适时尚 早春特惠 爆款休闲女鞋 赠运费险</a></div>
                        <div class="p-num">已售<em>2</em>件</div>
                    </li>
                    <li class="opacity_img">
                        <div class="p-img"><a href="#" target="_blank"><img src="__INDEX__/img/0_thumb_G_1489102753231.jpg" width="190" height="190"></a></div>
                        <div class="p-price"><em>¥</em>300.00</div>
                        <div class="p-name"><a href="#" target="_blank">新款韩版chic学生宽松短款外套上衣字母长袖连帽套头卫衣女潮</a></div>
                        <div class="p-num">已售<em>2</em>件</div>
                    </li>
                    <li class="opacity_img">
                        <div class="p-img"><a href="#" target="_blank"><img src="__INDEX__/img/0_thumb_G_1489109337889.jpg" width="190" height="190"></a></div>
                        <div class="p-price"><em>¥</em>330.00</div>
                        <div class="p-name"><a href="#" target="_blank">igtt铝框行李箱拉杆箱旅行箱万向轮男女20/24/26寸密码箱登机箱子 铝合金框 加强密码锁 万向轮 终身保修</a></div>
                        <div class="p-num">已售<em>1</em>件</div>
                    </li>
                    <li class="opacity_img">
                        <div class="p-img"><a href="#" target="_blank"><img src="__INDEX__/img/0_thumb_G_1489109282145.jpg" width="190" height="190"></a></div>
                        <div class="p-price"><em>¥</em>250.00</div>
                        <div class="p-name"><a href="#" target="_blank">波米铝框拉杆箱万向轮密码旅行箱子20/24寸行李箱女登机箱男26/28 顺丰速运赠运费险赠十礼品终身质保</a></div>
                        <div class="p-num">已售<em>1</em>件</div>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</div>





<div class="hide">

    <div id="dialog_remove" class="hide">
        <div class="tip-box icon-box">
            <span class="warn-icon m-icon"></span>
            <div class="item-fore">
                <h3 class="ftx-04">删除商品？</h3>
                <div class="ftx-03">您可以选择移到收藏，或删除商品。</div>
            </div>
        </div>
    </div>

    <div id="dialog_collect" class="hide">
        <div class="tip-box icon-box">
            <span class="warn-icon m-icon"></span>
            <div class="item-fore">
                <h3 class="ftx-04">移到收藏</h3>
                <div class="ftx-03">移动后选中商品将不在购物车中显示。</div>
            </div>
        </div>
    </div>

    <div id="flow_add_cart" class="hide">
        <div class="tip-box icon-box">
            <span class="warn-icon m-icon"></span>
            <div class="item-fore">
                <h3 class="ftx-04">请至少选中一件商品！</h3>
            </div>
        </div>
    </div>

    <div id="cart_gift_goods" class="hide">
        <div class="tip-box icon-box">
            <span class="warn-icon m-icon"></span>
            <div class="item-fore">
                <h3 class="ftx-04 rem">最多领取<em ectype="giftNumber"></em>个商品</h3>
            </div>
        </div>
    </div>




    <div id="set_default" class="hide">
        <div class="tip-box icon-box">
            <span class="warn-icon m-icon"></span>
            <div class="item-fore">
                <h3 class="ftx-04">您确定要设置为默认收货地址吗？</h3>
            </div>
        </div>
    </div>

    <div id="del_address" class="hide">
        <div class="tip-box icon-box">
            <span class="warn-icon m-icon"></span>
            <div class="item-fore">
                <h3 class="ftx-04">你确认要删除该收货地址吗？</h3>
            </div>
        </div>
    </div>

    <div id="no_address_cart" class="hide">
        <div class="tip-box icon-box">
            <span class="warn-icon m-icon"></span>
            <div class="item-fore">
                <h3 class="ftx-04">您还没有选择收货地址！</h3>
            </div>
        </div>
    </div>

    <div id="no_goods_cart" class="hide">
        <div class="tip-box icon-box">
            <span class="warn-icon m-icon"></span>
            <div class="item-fore">
                <h3 class="ftx-04">您的购物车中没有商品！</h3>
            </div>
        </div>
    </div>

    <div id="cart_address_not" class="hide">
        <div class="tip-box icon-box">
            <span class="warn-icon m-icon"></span>
            <div class="item-fore">
                <h3 class="ftx-04">您还没有选择收货地址！</h3>
            </div>
        </div>
    </div>


</div>
<div class="footer-new">
    <div class="footer-new-top">
        <div class="w w1200">
            <div class="service-list">
                <div class="service-item">
                    <i class="f-icon f-icon-qi"></i>
                    <span>七天包退</span>
                </div>
                <div class="service-item">
                    <i class="f-icon f-icon-zheng"></i>
                    <span>正品保障</span>
                </div>
                <div class="service-item">
                    <i class="f-icon f-icon-hao"></i>
                    <span>好评如潮</span>
                </div>
                <div class="service-item">
                    <i class="f-icon f-icon-shan"></i>
                    <span>闪电发货</span>
                </div>
                <div class="service-item">
                    <i class="f-icon f-icon-quan"></i>
                    <span>权威荣誉</span>
                </div>
            </div>
            <div class="contact">
                <div class="contact-item contact-item-first"><i class="f-icon f-icon-tel"></i><span>4000-000-000</span>
                </div>
                <div class="contact-item">
                    <a id="IM" im_type="dsc" onclick="openWin(this)" href="javascript:;" class="btn-ctn"><i
                            class="f-icon f-icon-kefu"></i><span>咨询客服</span></a>
                </div>
            </div>
        </div>
    </div>
    <div class="footer-new-con">
        <div class="fnc-warp">
            <div class="help-list">
                <?php if(is_array($helpCateRes) || $helpCateRes instanceof \think\Collection || $helpCateRes instanceof \think\Paginator): $i = 0; $__LIST__ = $helpCateRes;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$list): $mod = ($i % 2 );++$i;?>
                <div class="help-item">
                    <h3><?php echo $list['cate_name']; ?></h3>
                    <ul>
                        <?php if(is_array($list['arts']) || $list['arts'] instanceof \think\Collection || $list['arts'] instanceof \think\Paginator): $i = 0; $__LIST__ = $list['arts'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$list2): $mod = ($i % 2 );++$i;?>
                        <li><a href="<?php echo url('Article/index',array('artID'=>$list2['id'])); ?>"><?php echo $list2['title']; ?></a></li>
                        <?php endforeach; endif; else: echo "" ;endif; ?>
                    </ul>
                </div>
                <?php endforeach; endif; else: echo "" ;endif; ?>
            </div>
            <div class="qr-code">
                <div class="qr-item qr-item-first">
                    <div class="code_img"><img src="__INDEX__/img/ecjia_qrcode.png"></div>
                    <div class="code_txt">官方网址</div>
                </div>
                <div class="qr-item">
                    <div class="code_img"><img src="__INDEX__/img/ectouch_qrcode.png"></div>
                    <div class="code_txt">在线课程</div>
                </div>
            </div>
        </div>
    </div>
    <div class="footer-new-bot">
        <div class="w w1200">

            <p class="copyright_links">
                <a href="/">首页</a>
                <?php if(is_array($shopHelpArts) || $shopHelpArts instanceof \think\Collection || $shopHelpArts instanceof \think\Paginator): $i = 0; $__LIST__ = $shopHelpArts;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$list): $mod = ($i % 2 );++$i;?>
                <span class="spacer"></span>
                <a href="<?php echo url('Article/index',array('artID'=>$list['id'])); ?>"><?php echo $list['title']; ?></a>
                <?php endforeach; endif; else: echo "" ;endif; ?>
            </p>

            <p><span>©&nbsp;2015-2017&nbsp;tongpankt.com&nbsp;版权所有&nbsp;&nbsp;</span><span>ICP备案证书号:</span><a href="#">豫ICP备*****号-1</a>&nbsp;<a
                    href="#">POWERED by童攀课堂</a></p>

            <p class="copyright_auth">&nbsp;</p>
        </div>
    </div>


    <div class="hide" id="pd_coupons">
        <span class="success-icon m-icon"></span>
        <div class="item-fore">
            <h3>领取成功！感谢您的参与，祝您购物愉快~</h3>
            <div class="txt ftx-03">本活动为概率性事件，不能保证所有客户成功领取优惠券</div>
        </div>
    </div>


    <div class="hidden">
        <input name="seller_kf_IM" value="" rev="" ru_id="" type="hidden">
        <input name="seller_kf_qq" value="349488953" type="hidden">
        <input name="seller_kf_tel" value="4000-000-000" type="hidden">
        <input name="user_id" value="62" type="hidden">
    </div>
</div>
<script>
    // 2. 检查登录
    var check_log = "<?php echo url("member/Account/checkLogin"); ?>";
    // 3. 退出登录
    var login_out = "<?php echo url('member/Account/logoutA'); ?>";
    // 4. 去往登录页面
    var login_go = "<?php echo url('member/Account/login'); ?>";
    // 5. 去往注册页面
    var register_go = "<?php echo url('member/Account/reg'); ?>";
    // 更新头部购物车数量
    var cart_goods_num = "<?php echo url('index/Flow/cartGoodsNum'); ?>";
</script>
<script src="__INDEX__/js/check-log.js"></script>

<script type="text/javascript" src="__INDEX__/js/suggest.js"></script><script type="text/javascript" src="__INDEX__/js/scroll_city.js"></script><script type="text/javascript" src="__INDEX__/js/utils.js"></script>
<script type="text/javascript" src="__INDEX__/js/warehouse.js"></script><script type="text/javascript" src="__INDEX__/js/warehouse_area.js"></script>
<script type="text/javascript" src="__INDEX__/js/jquery.SuperSlide.2.1.1.js"></script><script type="text/javascript" src="__INDEX__/js/common.js"></script><script type="text/javascript" src="__INDEX__/js/shopping_flow.js"></script><script type="text/javascript" src="__INDEX__/js/jquery.nyroModal.js"></script><script type="text/javascript" src="__INDEX__/js/perfect-scrollbar/perfect-scrollbar.min.js"></script>
<script type="text/javascript" src="__INDEX__/js/dsc-common.js"></script>
<script type="text/javascript" src="__INDEX__/js/jquery.purebox.js"></script>
<script type="text/javascript" src="__INDEX__/js/region.js"></script>

<script type="text/javascript" src="__INDEX__/js/checkAll.js"></script>
<script type="text/javascript">
    function changenum(rec_id, diff, warehouse_id, area_id, favourable_id,obj){
        var cValue = $("#cart_value").val();
        // var goods_number = Number($('#goods_number_' + rec_id).val()) + Number(diff);
        if ($(obj).attr('class') == 'btn-add') {
            var goods_number = Number($(obj).parent().prev().val()) + Number(diff);
        } else {
            var goods_number = Number($(obj).parent().prev().val()) + Number(diff);
        }

        if(goods_number < 1){
            pbDialog(json_languages.Purchase_restrictions,"",0)
        }else{
            change_goods_number(rec_id,goods_number, warehouse_id, area_id, cValue, favourable_id);
        }
    }

    function change_goods_number(rec_id, goods_number, warehouse_id, area_id, cValue, favourable_id){
        if(cValue != "" || cValue == 'undefined'){
            var cValue = $("#cart_value").val();
        }
        if(goods_number == 0){
            //pbDialog("数量不能为0","",0);
            goods_number = 1;
        }

        var items = $("#checkItem_" +rec_id).parents("*[ectype='promoItem']");
        var input = items.find("*[ectype='ckGoods']");
        var str ='';
        input.each(function(){
            if($(this).prop('checked')== true){
                var val = $(this).val();
                str += val + ',';
            }
        });
        str = str.substring(str.length-1,0);

        Ajax.call("<?php echo url('index/Flow/updateCartNum'); ?>", 'rec_id=' + rec_id + '&sel_id=' + str + '&sel_flag=' + 'cart_sel_flag' +'&goods_number=' + goods_number +'&cValue=' + cValue +'&warehouse_id=' + warehouse_id +'&area_id=' + area_id +'&favourable_id=' + favourable_id, change_goods_number_response, 'POST','JSON');
    }

    function change_goods_number_response(result)
    {

        var rec_id = result.rec_id;
        if(result.error == 0){
            location.reload();
            $('#goods_number_' +rec_id).val(result.goods_number);//更新数量
            $('#goods_subtotal_' +rec_id).html(result.goods_subtotal);//更新小计

            if(result.dis_amount > 0){
                $('#discount_amount_' +rec_id).parents('.cuttip').removeClass("hide");
            }else{
                $('#discount_amount_' +rec_id).parents('.cuttip').addClass("hide");
            }

            $('#discount_amount_' +rec_id).html(result.discount_amount);//商品优惠价格

            if(result.goods_number == 1){
                $('#goods_number_' +rec_id).parents('.amount-warp').find('.btn-reduce').addClass("btn-disabled");
            }else{
                $('#goods_number_' +rec_id).parents('.amount-warp').find('.btn-reduce').removeClass("btn-disabled");
            }
            if(result.goods_number <= 0){
                $('#tr_goods_' +rec_id).style.display = 'none'; //数量为零则隐藏所在行
                $('#tr_goods_' +rec_id).innerHTML = '';
            }
            $('#total_desc').html(result.flow_info);//更新合计
            if ($('ECS_CARTINFO')){
                $('#ECS_CARTINFO').html(result.cart_info); //更新购物车数量
            }

            if(result.group.length > 0){
                for(var i=0; i<result.group.length; i++){
                    $("#" + result.group[i].rec_group).html(result.group[i].rec_group_number);//配件商品数量
                    $("#" + result.group[i].rec_group_talId).html(result.group[i].rec_group_subtotal);//配件商品金额
                }
            }

            $("#goods_price_" + rec_id).html(result.goods_price);
            $("*[ectype='save_total']").html(result.save_total_amount); //优惠节省总金额
            $("*[ectype='cartNum']").html(result.subtotal_number); //商品总数

            // 如果是优惠活动内的商品，更新优惠活动局部 qin
            if (result.act_id){
                $("#product_promo_" + result.ru_id + "_" + result.act_id).html(result.favourable_box_content);
            }
        }else if(result.message != ''){
            //更新数量
            $('#goods_number_' +rec_id).val(result.cart_Num);
            pbDialog(result.message," ",0,"",90,10);
        }
    }

    //购物车悬浮框
    cartScroll();

    //超值礼包
    $(".package_goods ul").perfectScrollbar("destroy");
    $(".package_goods ul").perfectScrollbar();
</script>

</body>
</html>