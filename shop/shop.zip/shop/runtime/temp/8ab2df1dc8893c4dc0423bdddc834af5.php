<?php if (!defined('THINK_PATH')) exit(); /*a:4:{s:72:"D:\phpstudy_pro\WWW\shop\public/../application/admin\view\goods\add.html";i:1597292256;s:76:"D:\phpstudy_pro\WWW\shop\public/../application/admin\view\public\header.html";i:1596878760;s:74:"D:\phpstudy_pro\WWW\shop\public/../application/admin\view\public\left.html";i:1597540726;s:76:"D:\phpstudy_pro\WWW\shop\public/../application/admin\view\public\footer.html";i:1596878877;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    


<meta charset="utf-8">
<title>童老师ThinkPHP交流群：484519446</title>

<meta name="description" content="Dashboard">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<!--Basic Styles-->
<link href="__ADMIN__/style/bootstrap.css" rel="stylesheet">
<link href="__ADMIN__/style/font-awesome.css" rel="stylesheet">
<link href="__ADMIN__/style/weather-icons.css" rel="stylesheet">

<!--Beyond styles-->
<link id="beyond-link" href="__ADMIN__/style/beyond.css" rel="stylesheet" type="text/css">
<link href="__ADMIN__/style/demo.css" rel="stylesheet">
<link href="__ADMIN__/style/typicons.css" rel="stylesheet">
<link href="__ADMIN__/style/animate.css" rel="stylesheet">
<script src="__PLUS__/ueditor/ueditor.config.js"></script>
<script src="__PLUS__/ueditor/ueditor.all.js"></script>
<script src="__PLUS__/ueditor/lang/zh-cn/zh-cn.js"></script>


</head>
<body>
<!-- 头部 -->
<div class="navbar">
    <div class="navbar-inner">
        <div class="navbar-container">
            <!-- Navbar Barnd -->
            <div class="navbar-header pull-left">
                <a href="#" class="navbar-brand">
                    <small>
                        <img src="__ADMIN__/images/logo.png" alt="">
                    </small>
                </a>
            </div>
            <!-- /Navbar Barnd -->
            <!-- Sidebar Collapse -->
            <div class="sidebar-collapse" id="sidebar-collapse">
                <i class="collapse-icon fa fa-bars"></i>
            </div>
            <!-- /Sidebar Collapse -->
            <!-- Account Area and Settings -->
            <div class="navbar-header pull-right">
                <div class="navbar-account">
                    <ul class="account-area">
                        <li>
                            <a class="login-area dropdown-toggle" data-toggle="dropdown">
                                <div class="avatar" title="View your public profile">
                                    <img src="__ADMIN__/images/adam-jansen.jpg">
                                </div>
                                <section>
                                    <h2><span class="profile"><span>admin</span></span></h2>
                                </section>
                            </a>
                            <!--Login Area Dropdown-->
                            <ul class="pull-right dropdown-menu dropdown-arrow dropdown-login-area">
                                <li class="username"><a>David Stevenson</a></li>
                                <li class="dropdown-footer">
                                    <a href="/admin/user/logout.html">
                                        退出登录
                                    </a>
                                </li>
                                <li class="dropdown-footer">
                                    <a href="/admin/user/changePwd.html">
                                        修改密码
                                    </a>
                                </li>
                            </ul>
                            <!--/Login Area Dropdown-->
                        </li>
                        <!-- /Account Area -->
                        <!--Note: notice that setting div must start right after account area list.
                            no space must be between these elements-->
                        <!-- Settings -->
                    </ul>
                </div>
            </div>
            <!-- /Account Area and Settings -->
        </div>
    </div>
</div>

<!-- /头部 -->

<div class="main-container container-fluid">
    <div class="page-container">
        <!-- Page Sidebar -->
        <div class="page-sidebar" id="sidebar">
    <!-- Page Sidebar Header-->
    <div class="sidebar-header-wrapper">
        <input class="searchinput" type="text">
        <i class="searchicon fa fa-search"></i>
        <div class="searchhelper">Search Reports, Charts, Emails or Notifications</div>
    </div>
    <!-- /Page Sidebar Header -->
    <!-- Sidebar Menu -->
    <ul class="nav sidebar-menu">
        <!--Dashboard-->
        <li>
            <a href="#" class="menu-dropdown">
                <i class="menu-icon fa fa-user"></i>
                <span class="menu-text">商品管理</span>
                <i class="menu-expand"></i>
            </a>
            <ul class="submenu">
                <li>
                    <a href="<?php echo url('Goods/lists'); ?>">
                        <span class="menu-text">商品列表</span>
                        <i class="menu-expand"></i>
                    </a>
                </li>
                <li>
                    <a href="<?php echo url('Goods/add'); ?>">
                        <span class="menu-text">添加商品</span>
                        <i class="menu-expand"></i>
                    </a>
                </li>
                <li>
                    <a href="<?php echo url('Brand/lists'); ?>">
                        <span class="menu-text">商品品牌</span>
                        <i class="menu-expand"></i>
                    </a>
                </li>
                <li>
                    <a href="<?php echo url('Category/lists'); ?>">
                        <span class="menu-text">商品分类</span>
                        <i class="menu-expand"></i>
                    </a>
                </li>
                <li>
                    <a href="<?php echo url('Type/lists'); ?>">
                        <span class="menu-text">商品类型</span>
                        <i class="menu-expand"></i>
                    </a>
                </li>
                <li>
                    <a href="<?php echo url('Brand/lists'); ?>">
                        <span class="menu-text">商品回收站</span>
                        <i class="menu-expand"></i>
                    </a>
                </li>
            </ul>
        </li>

        <li>
            <a href="#" class="menu-dropdown">
                <i class="menu-icon fa fa-user"></i>
                <span class="menu-text">促销管理</span>
                <i class="menu-expand"></i>
            </a>
            <ul class="submenu">
                <li>
                    <a href="/admin/Brand/lists">
                        <span class="menu-text">团购活动</span>
                        <i class="menu-expand"></i>
                    </a>
                </li>
                <li>
                    <a href="/admin/Brand/lists">
                        <span class="menu-text">积分商城</span>
                        <i class="menu-expand"></i>
                    </a>
                </li>
                <li>
                    <a href="/admin/Brand/lists">
                        <span class="menu-text">优惠券</span>
                        <i class="menu-expand"></i>
                    </a>
                </li>
                <li>
                    <a href="/admin/Brand/lists">
                        <span class="menu-text">商品</span>
                        <i class="menu-expand"></i>
                    </a>
                </li>
            </ul>
        </li>

        <li>
            <a href="#" class="menu-dropdown">
                <i class="menu-icon fa fa-user"></i>
                <span class="menu-text">推荐位管理</span>
                <i class="menu-expand"></i>
            </a>
            <ul class="submenu">
                <li>
                    <a href="<?php echo url('Recpos/lists'); ?>">
                        <span class="menu-text">推荐位列表</span>
                        <i class="menu-expand"></i>
                    </a>
                </li>
                <li>
                    <a href="<?php echo url('Recpos/add'); ?>">
                        <span class="menu-text">添加推荐位</span>
                        <i class="menu-expand"></i>
                    </a>
                </li>
            </ul>
        </li>

        <li>
            <a href="#" class="menu-dropdown">
                <i class="menu-icon fa fa-user"></i>
                <span class="menu-text">栏目关联管理</span>
                <i class="menu-expand"></i>
            </a>
            <ul class="submenu">
                <li>
                    <a href="<?php echo url('CategoryWords/lists'); ?>">
                        <span class="menu-text">推荐词关联</span>
                        <i class="menu-expand"></i>
                    </a>
                </li>
                <li>
                    <a href="<?php echo url('CategoryBrands/lists'); ?>">
                        <span class="menu-text">品牌关联</span>
                        <i class="menu-expand"></i>
                    </a>
                </li>
                <li>
                    <a href="<?php echo url('CategoryAd/lists'); ?>">
                        <span class="menu-text">栏目右侧广告</span>
                        <i class="menu-expand"></i>
                    </a>
                </li>
            </ul>
        </li>

        <li>
            <a href="#" class="menu-dropdown">
                <i class="menu-icon fa fa-user"></i>
                <span class="menu-text">会员管理</span>
                <i class="menu-expand"></i>
            </a>
            <ul class="submenu">
                <li>
                    <a href="<?php echo url('MemberLevel/lists'); ?>">
                        <span class="menu-text">会员列表</span>
                        <i class="menu-expand"></i>
                    </a>
                </li>
                <li>
                    <a href="<?php echo url('MemberLevel/lists'); ?>">
                        <span class="menu-text">会员级别</span>
                        <i class="menu-expand"></i>
                    </a>
                </li>
                <li>
                    <a href="<?php echo url('MemberLevel/lists'); ?>">
                        <span class="menu-text">会员留言</span>
                        <i class="menu-expand"></i>
                    </a>
                </li>
            </ul>
        </li>

        <li>
            <a href="#" class="menu-dropdown">
                <i class="menu-icon fa fa-user"></i>
                <span class="menu-text">文章模块</span>
                <i class="menu-expand"></i>
            </a>
            <ul class="submenu">
                <li>
                    <a href="<?php echo url('Cate/lists'); ?>">
                        <span class="menu-text">文章分类</span>
                        <i class="menu-expand"></i>
                    </a>
                </li>
                <li>
                    <a href="<?php echo url('Article/lists'); ?>">
                        <span class="menu-text">文章管理</span>
                        <i class="menu-expand"></i>
                    </a>
                </li>
                <li>
                    <a href="<?php echo url('Article/imglist'); ?>">
                        <span class="menu-text">图片管理</span>
                        <i class="menu-expand"></i>
                    </a>
                </li>
                <li>
                    <a href="<?php echo url('alternateImg/lists'); ?>">
                        <span class="menu-text">轮播图管理</span>
                        <i class="menu-expand"></i>
                    </a>
                </li>
            </ul>
        </li>

        <li>
            <a href="#" class="menu-dropdown">
                <i class="menu-icon fa fa-user"></i>
                <span class="menu-text">导航管理</span>
                <i class="menu-expand"></i>
            </a>
            <ul class="submenu">
                <li>
                    <a href="<?php echo url('Nav/lists'); ?>">
                        <span class="menu-text">导航列表</span>
                        <i class="menu-expand"></i>
                    </a>
                </li>
                <li>
                    <a href="<?php echo url('Nav/add'); ?>">
                        <span class="menu-text">添加导航</span>
                        <i class="menu-expand"></i>
                    </a>
                </li>
            </ul>
        </li>

        <li>
            <a href="#" class="menu-dropdown">
                <i class="menu-icon fa fa-user"></i>
                <span class="menu-text">系统设置</span>
                <i class="menu-expand"></i>
            </a>
            <ul class="submenu">
                <li>
                    <a href="<?php echo url('Conf/conflist'); ?>">
                        <span class="menu-text">配置项</span>
                        <i class="menu-expand"></i>
                    </a>
                </li>
                <li>
                    <a href="<?php echo url('Conf/lists'); ?>">
                        <span class="menu-text">配置管理</span>
                        <i class="menu-expand"></i>
                    </a>
                </li>
                <li>
                    <a href="<?php echo url('Conf/lists'); ?>">
                        <span class="menu-text">支付方式设置</span>
                        <i class="menu-expand"></i>
                    </a>
                </li>
            </ul>
        </li>
        <li>
            <a href="#" class="menu-dropdown">
                <i class="menu-icon fa fa-link"></i>
                <span class="menu-text">友情链接</span>
                <i class="menu-expand"></i>
            </a>
            <ul class="submenu">
                <li>
                    <a href="<?php echo url('Link/lists'); ?>">
                        <span class="menu-text">链接管理</span>
                        <i class="menu-expand"></i>
                    </a>
                </li>
            </ul>
        </li>

        

    </ul>
    <!-- /Sidebar Menu -->
</div>
        <!-- /Page Sidebar -->
        <!-- Page Content -->
        <div class="page-content">
            <!-- Page Breadcrumb -->
            <div class="page-breadcrumbs">
                <ul class="breadcrumb">
                    <li>
                        <a href="<?php echo url('Index/index'); ?>">系统</a>
                    </li>
                    <li>
                        <a href="<?php echo url('lists'); ?>">商品管理</a>
                    </li>
                    <li class="active">添加商品</li>
                </ul>
            </div>
            <!-- /Page Breadcrumb -->

            <!-- Page Body -->
            <div class="page-body">
                <div class="row">
                    <div class="col-lg-12 col-sm-12 col-xs-12">
                        <div class="widget">
                            <form class="form-horizontal" role="form" action="<?php echo url('add'); ?>" method="post" enctype="multipart/form-data">
                                <div class="widget-body">
                                    <div class="widget-main">
                                        <div class="tabbable">
                                            <ul class="nav nav-tabs tabs-flat" id="myTab11">
                                                <li class="active">
                                                    <a data-toggle="tab" href="#baseinfo">商品基本信息</a>
                                                </li>
                                                <li class="">
                                                    <a data-toggle="tab" href="#goodsdes">描述信息</a>
                                                </li>
                                                <li class="">
                                                    <a data-toggle="tab" href="#mbprice">会员价格</a>
                                                </li>
                                                <li class="">
                                                    <a data-toggle="tab" href="#goodsattr">商品属性</a>
                                                </li>
                                                <li class="">
                                                    <a data-toggle="tab" href="#goodsphoto">商品相册</a>
                                                </li>
                                            </ul>
                                            <div class="tab-content tabs-flat">
<!--                                                商品基本信息-->
                                                <div id="baseinfo" class="tab-pane active">
                                                    <div class="form-group">
                                                        <label for="username"
                                                               class="col-sm-2 control-label no-padding-right">商品名称</label>
                                                        <div class="col-sm-6">
                                                            <input class="form-control"  name="goods_name"
                                                                   type="text">
                                                        </div>
                                                        <p class="help-block col-sm-4 red">* 必填</p>
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="username" class="col-sm-2 control-label no-padding-right">推荐位</label>
                                                        <div class="col-sm-6">
                                                            <!-- 单行文本 -->
                                                            <div class="checkbox">
                                                                <?php if(is_array($recposList) || $recposList instanceof \think\Collection || $recposList instanceof \think\Paginator): $i = 0; $__LIST__ = $recposList;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$list): $mod = ($i % 2 );++$i;?>
                                                                <label>
                                                                    <input type="checkbox" value="<?php echo $list['id']; ?>" name="recpos[]" class="colored-blue">
                                                                    <span class="text"><?php echo $list['rec_name']; ?> </span>&nbsp;&nbsp;&nbsp;
                                                                </label>
                                                                <?php endforeach; endif; else: echo "" ;endif; ?>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="username"
                                                               class="col-sm-2 control-label no-padding-right">商品主图</label>
                                                        <div class="col-sm-6">
                                                            <input class="form-control" name="og_thumb"
                                                                   type="file">
                                                        </div>
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="status" class="col-sm-2 control-label no-padding-right">上架</label>
                                                        <div class="radio" style="float: left;padding-left: 15px;">
                                                            <label>
                                                                <input type="radio" name="on_sale" class="colored-blue" checked value="1">
                                                                <span class="text">是</span>
                                                            </label>
                                                        </div>
                                                        <div class="radio" style="float: left;padding-right: 10px;padding-left: 15px;">
                                                            <label>
                                                                <input type="radio" name="on_sale" class="colored-blue" value="0">
                                                                <span class="text">否</span>
                                                            </label>
                                                        </div>
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="username"
                                                               class="col-sm-2 control-label no-padding-right">所属栏目</label>
                                                        <div class="col-sm-6">
                                                            <select name="category_id">
                                                                <option value="">所属商品栏目</option>
                                                                <?php if(is_array($cateTreeList) || $cateTreeList instanceof \think\Collection || $cateTreeList instanceof \think\Paginator): $i = 0; $__LIST__ = $cateTreeList;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$list): $mod = ($i % 2 );++$i;?>
                                                                <option value="<?php echo $list['id']; ?>">
                                                                    <?php echo str_repeat('|-----',$list['level'])?><?php echo $list['cate_name']; ?>
                                                                </option>
                                                                <?php endforeach; endif; else: echo "" ;endif; ?>
                                                            </select>
                                                        </div>
                                                        <p class="help-block col-sm-4 red">* 必填</p>
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="username"
                                                               class="col-sm-2 control-label no-padding-right">所属品牌</label>
                                                        <div class="col-sm-6">
                                                            <select name="brand_id">
                                                                <option value="">顶级分类</option>
                                                                <?php if(is_array($brandList) || $brandList instanceof \think\Collection || $brandList instanceof \think\Paginator): $i = 0; $__LIST__ = $brandList;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$list): $mod = ($i % 2 );++$i;?>
                                                                <option value="<?php echo $list['id']; ?>"><?php echo $list['brand_name']; ?></option>
                                                                <?php endforeach; endif; else: echo "" ;endif; ?>
                                                            </select>
                                                        </div>
                                                        <p class="help-block col-sm-4 red">* 必填</p>
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="username"
                                                               class="col-sm-2 control-label no-padding-right">市场价</label>
                                                        <div class="col-sm-6">
                                                            <input class="form-control"   name="markte_price"
                                                                   type="text">
                                                        </div>
                                                        <p class="help-block col-sm-4 red">* 必填</p>
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="username"
                                                               class="col-sm-2 control-label no-padding-right">零售价</label>
                                                        <div class="col-sm-6">
                                                            <input class="form-control"   name="shop_price"
                                                                   type="text">
                                                        </div>
                                                        <p class="help-block col-sm-4 red">* 必填</p>
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="username"
                                                               class="col-sm-2 control-label no-padding-right">重量</label>
                                                        <div class="col-sm-6" style="width: 300px;display: inline-block;">
                                                            <input class="form-control"  name="goods_weight"
                                                                   type="text">
                                                        </div>
                                                        <select name="weight_unit" id="">
                                                            <option value="kg">kg</option>
                                                            <option value="g">g</option>
                                                        </select>
                                                    </div>
                                                </div>
<!--                                                描述信息-->
                                                <div id="goodsdes" class="tab-pane">
                                                    <textarea id="content"  name="goods_des"></textarea>
                                                </div>
<!--                                                会员价格-->
                                                <div id="mbprice" class="tab-pane">
                                                    <?php if(is_array($mList) || $mList instanceof \think\Collection || $mList instanceof \think\Paginator): $i = 0; $__LIST__ = $mList;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$list): $mod = ($i % 2 );++$i;?>
                                                    <div class="form-group">
                                                        <label for="username"
                                                               class="col-sm-2 control-label no-padding-right"><?php echo $list['level_name']; ?></label>
                                                        <div class="col-sm-6">
                                                            <input class="form-control" name="mp[<?php echo $list['id']; ?>]" type="text">
                                                        </div>
                                                        <p class="help-block col-sm-4 red">* 必填</p>
                                                    </div>
                                                    <?php endforeach; endif; else: echo "" ;endif; ?>
                                                </div>
<!--                                                商品属性-->
                                                <div id="goodsattr" class="tab-pane">
                                                    <div class="form-group">
                                                        <label for="username"
                                                               class="col-sm-2 control-label no-padding-right">商品类型</label>
                                                        <div class="col-sm-6">
                                                            <select name="type_id">
                                                                <option value="">顶级分类</option>
                                                                <?php if(is_array($typeList) || $typeList instanceof \think\Collection || $typeList instanceof \think\Paginator): $i = 0; $__LIST__ = $typeList;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$list): $mod = ($i % 2 );++$i;?>
                                                                <option value="<?php echo $list['id']; ?>"><?php echo $list['type_name']; ?></option>
                                                                <?php endforeach; endif; else: echo "" ;endif; ?>
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div id="attr_list"><!--属性显示Ajax--></div>
                                                </div>
<!--                                                商品相册-->
                                                <div id="goodsphoto" class="tab-pane">
                                                    <div class="form-group">
                                                        <label for="username" class="col-sm-2 control-label no-padding-right"></label>
                                                        <div class="col-sm-6">
                                                            <a href="#" onclick="addrow(this)">[+]</a>
                                                            <input style="border:none;box-shadow: none;width: 50%;display: inline-block"
                                                                   class="form-control" name="goods_photo[]" type="file">
                                                        </div>
                                                        <p class="help-block col-sm-4 red">* 必填</p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <div class="col-sm-offset-2 col-sm-10">
                                                <button type="submit" class="btn btn-default">保存信息</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <!-- /Page Body -->
        </div>
        <!-- /Page Content -->
    </div>
</div>

<!--Basic Scripts-->
<script src="__ADMIN__/style/jquery_002.js"></script>
<script src="__ADMIN__/style/bootstrap.js"></script>
<script src="__ADMIN__/style/jquery.js"></script>
<!--Beyond Scripts-->
<script src="__ADMIN__/style/beyond.js"></script>
<script>
    UE.getEditor('content',{initialFrameWidth:800,initialFrameHeight:400})
</script>


</body>
<script>
    // 选择商品类型，弹出对应的商品属性值
    $("select[name=type_id]").change(function(){
        // 获取哦option的value值
        var type_id = $(this).val();
        $.ajax({
            type : "POST",
            url : "<?php echo url('Attr/ajaxGetAttr'); ?>",
            data : {type_id : type_id},
            dataType : "json",
            success : function(data) {
                var html = "";
                console.log(data);
                $(data).each(function(k,v){
                    // 属性类型是单选时，选用下拉框
                    if (v.attr_type == 1) {
                        html+="<div class='form-group'>";
                        html+="<label class='col-sm-2 control-label no-padding-right'>"+v.attr_name+"</label>";
                        // 属性值多个时，使用,分割成数组
                        var attrValuesArr = v.attr_values.split(",");
                        console.log(attrValuesArr);
                        html+="<div class='col-sm-6'><a onclick='addrow(this)' href='#'>[+]</a>&nbsp;&nbsp;";
                        html+="<select name='goods_attr["+v.id+"][]'>";
                        html+="<option value=''>请选择</option>";
                        for (var i = 0; i < attrValuesArr.length; i++) {
                            html+="<option value='"+attrValuesArr[i]+"'>"+attrValuesArr[i]+"</option>";
                        }
                        html+="</select>";
                        html+="&nbsp;&nbsp;<input name='attr_price[]' class='form-control' style='width: 150px;display: inline-block;' type='text' placeholder='价格'>";
                        html+="</div></div>";

                    } else {
                        // 唯一值处理
                        if (v.attr_values) {
                            html+="<div class='form-group'>";
                            html+="<label class='col-sm-2 control-label no-padding-right'>"+v.attr_name+"</label>&nbsp;&nbsp;";
                            // 属性值多个时，使用,分割成数组
                            var attrValuesArr = v.attr_values.split(",");
                            html+="<select name='goods_attr["+v.id+"]'>";
                            html+="<option value=''>请选择</option>";
                            for (var i = 0; i < attrValuesArr.length; i++) {
                                html+="<option value='"+attrValuesArr[i]+"'>"+attrValuesArr[i]+"</option>";
                            }
                            html+="</select>";
                            html+="</div></div>";
                        } else {
                            html+="<div class='form-group'>";
                            html+="<label class='col-sm-2 control-label no-padding-right'>"+v.attr_name+"</label>";
                            var attrValuesArr = v.attr_values.split(",");
                            html+="&nbsp;&nbsp;<input name='goods_attr["+v.id+"]' class='form-control' style='width: 150px;display: inline-block;' type='text'>";
                            html+="</div></div>";
                        }
                    }
                });
                $('#attr_list').html(html);
            }
        });
    });

    function addrow(obj) {
        var div = $(obj).parent().parent();
        if ($(obj).html() == '[+]') {
            var newdiv = div.clone();
            newdiv.find('a').html('[-]');
            div.after(newdiv);
        } else {
            div.remove();
        }
    }
</script>
</html>