<?php
namespace app\member\controller;


class User extends Base
{
    public function index() {
        return view();
    }



}